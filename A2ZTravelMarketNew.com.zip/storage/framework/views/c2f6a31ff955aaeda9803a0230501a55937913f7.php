<?php $__env->startSection('meta_tags'); ?>
<title>Write a Review</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header-nav'); ?>
<?php echo $__env->make('Web.nav-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>



<div class="row intital-pages" style="margin-bottom: 30px;">
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <div class="row write-success">
                    <?php if(session('success')): ?>
                    <i class="fa fa-check"></i> <?php echo e(session('success')); ?>

                    <?php endif; ?>
                    <i class="fa fa-check"></i> Your Review has been submited
                </div>
                <div class="row reviews-all">
                    <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <div class="review-show">

                        <div class="row">
                            <div class="col-md-9">
                                <h2>"<?php echo e($review->title); ?>"</h2>
                                <div class="review-show-rate">
                                    <?php echo e(App\Http\Controllers\ReviewController::getRateStar($review->overall_rating)); ?>


                                </div>
                                <div class="review-show-msg">
                                    <?php echo e($review->review); ?>

                                </div>
                                <div class="review-show-owner">
                                    reviewed by <span><?php echo e($review->user_name); ?> – <?php echo e($review->user_country); ?></span>
                                </div>
                            </div>
                            <span class="review-show-date"><?php echo e(date('F d, Y',strtotime($review->visit_date))); ?></span>
                            <div class="review-helpfull">
                                Was this helpful? <a href="#" class="btn btn-default">yes</a>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </div>
            </div>
            <div class="col-md-4">
                <?php echo $__env->make('Web.Layouts.rightSide', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>

        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('_extra_css'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('_extra_js'); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('Web.Layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>