<?php $__env->startSection('_extra_css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('adminlte/plugins/daterangepicker/daterangepicker.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('adminlte/plugins/datepicker/datepicker3.css')); ?>">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="main-box row">
    <div class="booking_method row">
        <div class="col-md-4 first-method"> <span><?php echo e(Vars::getVar('Add_to_cart')); ?></span></div>
        <div class="col-md-4 second-methode"> <span><?php echo e(Vars::getVar('Review_order')); ?></span></div>
        <div class="col-md-4 third-methode"> <span><?php echo e(Vars::getVar('Secure_checkout')); ?></span></div>
    </div>
    <div id="list_refrence">
        <div class="left">
            <h1><?php echo e(Vars::getVar('Review_your_order')); ?></h1>
            <div> <?php echo e(Vars::getVar('Items_in_cart')); ?>: <?php echo e(Session::has('cart')?Session::get('cart')->totalQty:0); ?></div>
        </div>
        <div class="right">
            <div> <?php echo e(Vars::getVar('Current_cart_total')); ?> </div>
            <h1><span><?php echo e(Vars::getVar('Currency_label')); ?></span><?php echo e($total); ?></h1>
        </div>
    </div>
    <form action="" method="post">
        <div class="row checkout-field">
            <div class="col-md-3"><span><label>*</label> <?php echo e(Vars::getVar('Name')); ?></span></div>
            <div class="col-md-7">
                <input class="form-control" type="text" name="name" placeholder="Full Name" required/>
            </div>
        </div>
        <div class="row checkout-field">
            <div class="col-md-3"><span> <?php echo e(Vars::getVar('Nationality')); ?></span></div>
            <div class="col-md-7">
                <input class="form-control" type="text" name="nationality" placeholder="Full Name" />
            </div>
        </div>
        <div class="row checkout-field">
            <div class="col-md-3"><span><label>*</label> <?php echo e(Vars::getVar('Email')); ?></span></div>
            <div class="col-md-7">
                <input class="form-control" type="email" name="email" placeholder="Full Name" required/>
            </div>
        </div>
        <div class="row checkout-field">
            <div class="col-md-3"><span> <?php echo e(Vars::getVar('Mobile')); ?></span></div>
            <div class="col-md-7">
                <div class="input-group">
                    <div class="input-group-addon">
                        <i class="fa fa-phone"></i>
                    </div>
                    <input type="text" class="form-control" name="mobile" data-inputmask="'mask': ['999-999-9999 [x99999]', '+99 999 999 99999999']" data-mask>
                </div>

            </div>
        </div>
        <div class="row checkout-field">
            <div class="col-md-3"><span><label>*</label> <?php echo e(Vars::getVar('Hotel')); ?></span></div>
            <div class="col-md-7">
                <input class="form-control" type="text" name="hotel" placeholder="Full Name" required/>
            </div>
        </div>
        <div class="row checkout-field">
            <div class="col-md-3"><span> <?php echo e(Vars::getVar('Tour_Operator')); ?></span></div>
            <div class="col-md-7">
                <input class="form-control" type="text" name="tour_operator" placeholder="Full Name" />
            </div>
        </div>

        <div class="row checkout-field">
            <div class="col-md-3"><span> <?php echo e(Vars::getVar('Departure&Arrival_Date-Time')); ?></span></div>
            <div class="col-md-7">
                <div class="input-group">
                    <div class="input-group-addon">
                        <i class="fa fa-clock-o"></i>
                    </div>
                    <input type="text" class="form-control pull-right" id="reservationtime">
                </div>

            </div>
        </div>
        <div class="row checkout-field">
            <div class="col-md-3"><span><?php echo e(Vars::getVar('Flight_NO')); ?></span></div>
            <div class="col-md-7">
                <input class="form-control" type="text" name="flight_no" placeholder="Full Name" />
            </div>
        </div>
        <div class="row checkout-field">
            <div class="col-md-3"><span><?php echo e(Vars::getVar('Message')); ?></span></div>
            <div class="col-md-7">
                <textarea class="form-control" name="msg"></textarea>
            </div>
        </div>
        <div class="row checkout-submit-cover">
            <input type="submit" value="" class="checkout-submit">
        </div>
    </form>



</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('_extra_js'); ?>
<script src="<?php echo e(asset('adminlte/plugins/input-mask/jquery.inputmask.js')); ?>"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.11.2/moment.min.js"></script>
<script src="<?php echo e(asset('adminlte/plugins/daterangepicker/daterangepicker.js')); ?>"></script>


<script>
$(function() {
    $("[data-mask]").inputmask();
    //Datemask dd/mm/yyyy
    $("#datemask").inputmask("dd/mm/yyyy", {"placeholder": "dd/mm/yyyy"});
    $('#reservationtime').daterangepicker({timePicker: true, timePickerIncrement: 30, format: 'DD/MM/YYYY h:mm A'});
});
</script>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('Web.Layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>