<div class="row form-under-transfer form-transfer-show">
    <div class="container">
        <div style="display: none">
            <form id="getDestFrom" method="get" action="<?php echo e(route('searchDist')); ?>">

            </form>
        </div>
        <form method="post" action="<?php echo e(route('transfer.get')); ?>">
            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"/>
            <div class="col-md-5">
                <div class="form-group">

                    <div class="input-group">
                        <div class="input-group-addon input-transfer">
                            <i class="fa fa-plane fa-lg"></i>
                        </div>
                        <div class="transfer-input-label">
                            <label><?php echo e(Vars::getVar('Which_airport_are_you_arriving_at?')); ?></label>

                            <select  name="dist_from"class="form-control" id="dist_from_2">
                                <option>Eg. Sharm El Sheikh Airport</option>
                                <?php $__currentLoopData = App\MyModels\Admin\Transfer::select('dist_from')->groupBy('dist_from')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transfer): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <option value="<?php echo e($transfer->dist_from); ?>"><?php echo e($transfer->dist_from); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            </select>

                        </div>

                    </div>
                </div>

            </div>
            <div class="col-md-5">
                <div class="form-group">

                    <div class="input-group">
                        <div class="input-group-addon input-transfer">
                            <i class="fa fa-map-marker fa-lg"></i>
                        </div>
                        <div class="transfer-input-label">
                            <label><?php echo e(Vars::getVar('Where_do_you_want_to_go?')); ?></label>
                            <select name="dist_to" class="form-control" id="dist_to">
                                <option>Eg. Nabq Hotels</option>
                            </select>
                        </div>

                    </div>
                </div>

            </div>
            <div class="col-md-2">
                <button class="btn btn-success btn-lg btn-block"><?php echo e(Vars::getVar('Continue')); ?></button>
            </div>
        </form>
    </div>
</div>