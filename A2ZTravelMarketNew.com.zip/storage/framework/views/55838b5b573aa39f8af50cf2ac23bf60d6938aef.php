<?php $__env->startSection('title','Items Panel | Update'); ?>
<?php $__env->startSection('Extra_Css'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/admin/style.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <!-- Directory&Header -->
    <section class="content-header">
        <h1>Items <small>Gallery</small> </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> C-Panel</a></li>
            <li><a href="#">Update Items :<?php echo e(App\MyModels\Admin\Item::find($item)->name); ?> </a></li>
        </ol>
    </section>
    <!-- end Directory&Header -->
    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-header with-border">
                        <h3 class="box-title"><a href="#"><i class="fa fa-android"></i> Gallery List</a></h3>
                    </div>
                    <div class="box-body">
                        <?php if($errors->has('id')): ?>
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="alert alert-danger alert-dismissible">
                                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                    <h4><i class="icon fa fa-ban"></i> Oops! Something went wrong. </h4>
                                    You have to select One Image at less
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>
                        <div class="row with-border">
                            <div class="col-sm-2">
                                <div class="form-group">
                                    <select class="form-control" id="selectNav">
                                        <option>Select</option>
                                        <option value="all">All</option>
                                        <option value="none">None</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <form method="post" action="<?php echo e(route('ItemGallery.destroy',['$id'=>$item])); ?>">
                            <input type="hidden" value="DELETE" name="_method">
                            <input type="hidden" value="<?php echo e(csrf_token()); ?>" name="_token">
                            <?php $__currentLoopData = $images->chunk(6); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <div class="row margin-bottom">
                                <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <div class="col-sm-2" style="text-align: center;">
                                    <img src="<?php echo e(asset('images/gallery/thumb/'.$image->img)); ?>" alt="..." class="img-rounded margin-bottom" width="100%">
                                    <div class="form-group">
                                        <div class="checkbox">
                                            <label>
                                                <input type="checkbox" class="checkbox" name="id[]" value="<?php echo e($image->id); ?>">
                                            </label>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            <div class="row">
                                <div class="col-md-12">
                                    <a href="<?php echo e(route('Items.edit',['item'=>$item])); ?>" class="btn btn-bitbucket"><i class="fa fa-dashboard"></i> Return Back to Item Dashboard</a>
                                    <button class="btn btn-danger"><i class="fa fa-trash"></i> Delete</button>
                                    <a href="<?php echo e(route('ItemGallery.create',['id'=>$item])); ?>" class="btn btn-primary">Upload New Images</a>
                                </div>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </section>
    <!-- end content -->
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('Extra_Js'); ?>
<script src="<?php echo e(asset('js/admin/admin.js')); ?>"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.Layouts.Layout_Basic', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>