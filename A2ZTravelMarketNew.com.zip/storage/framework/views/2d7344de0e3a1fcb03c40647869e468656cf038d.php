<?php $__env->startSection('meta_tags'); ?>
<title><?php echo e($category->title); ?></title>
<meta name="keywords" content="<?php echo e($category->keywords); ?>">
<meta name="description" content="<?php echo e($category->description); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header-nav'); ?>
<?php echo $__env->make('Web.nav-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="row intital-pages">
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <div class="sort-deatils">
                    <img class="img-abs-center" src="<?php echo e(asset('images/sorts/'.$category->img)); ?>" alt="<?php echo e($category->title); ?>">
                    <div class="sort-info">
                        <h1>
                            <i class="fa fa-map-marker"></i>
                            <?php echo e($category->title); ?></h1>
                        <p>
                            <?php echo e($category->txt); ?>

                        </p>
                    </div>
                </div>
                <div class="items">
                    <?php $__currentLoopData = $category->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <div class="row exc-items">
                        <div class="col-md-4">
                            <div class="exc-item-img">
                                <div class="exc-item-img-container">
                                    <img src="<?php echo e(asset('images/items/thumb/'.$item->img)); ?>" alt="<?php echo e($item->title); ?>" class="img-abs-center">
                                </div>
                                <span class="fa fa-caret-left fa-4x"></span>
                                <div class="exc-img-shadow"></div>
                            </div>
                        </div>
                        <div class="col-md-8 exc-item-info">
                            <div class="row">
                                <div class="col-md-12">
                                    <h2><?php echo e($item->name); ?></h2>
                                    <span class="exc-item-duration"><i class="fa fa-clock-o fa-lg" aria-hidden="true"></i>
                                        <label><?php echo e(Vars::getVar('Duration')); ?>:</label>
                                        <?php echo isset($item->detail)?$item->detail->duration:0; ?>

                                        <?php echo e(Vars::getVar('hours')); ?></span>
                                    <p>
                                        <?php echo e(str_limit($item->intro, $limit = 100, $end = '...')); ?>

                                    </p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 text-right">
                                    <button class="btn btn-warning" style="width: 60%; background-color: #ffd924; border: 1px solid #ffd924;">
                                        <?php if(isset($item->price)): ?>
                                        <?php echo e(Vars::getVar('£')); ?><?php echo e(sprintf('%.2f',$item->price->st_price)); ?>

                                        <?php endif; ?>
                                    </button>
                                </div>
                                <div class="col-md-6">
                                    <a href="<?php echo e(route('tour.show',['city'=>urlencode($item->sort->name),'tour'=>urlencode($item->name),'id'=>$item->id])); ?>" class="btn btn-warning">
                                        <i class="fa fa-shopping-cart fa-lg" aria-hidden="true"></i> <?php echo e(Vars::getVar('Add_to_Basket')); ?>

                                    </a>
                                </div>
                            </div>

                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </div>

            </div>
            <!-- content right side -->
            <div class="col-md-4" style="padding-left: 30px;">
                <!-- transfer form -->
                <?php echo $__env->make('Web.Layouts.TransferForm', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <!-- transfer form end -->
                <?php echo $__env->make('Web.Layouts.rightSide', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
            <!-- content right side end -->
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('_extra_css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/datepicker/zebra_datepicker.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('_extra_js'); ?>
<script type="text/javascript" src="<?php echo e(asset('js/datepicker/zebra_datepicker.min.js')); ?>"></script>
<script>
$('#arrival_date').Zebra_DatePicker({
    direction: true,
    format: 'Y-m-d',
    default_position: 'below',
    pair: $('#departure_date'),
    onSelect: function() {
        $('#departure_date').trigger('click');
    }
    //    disabled_dates: ['* * * 0,1,2,6']
});
$('#departure_date').Zebra_DatePicker({
    direction: true,
    format: 'Y-m-d',
    pair: $('#arrival_date'),
    default_position: 'below'
            //    disabled_dates: ['* * * 0,1,2,6']
});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Web.Layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>