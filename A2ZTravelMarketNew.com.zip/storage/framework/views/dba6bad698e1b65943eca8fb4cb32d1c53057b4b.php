<?php $__env->startSection('meta_tags'); ?>
<title><?php echo e($item->title); ?></title>
<meta name="keywords" content="<?php echo e($item->keywords); ?>">
<meta name="description" content="<?php echo e($item->description); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('_extra_css'); ?>

<link rel="stylesheet" href="<?php echo e(asset('adminlte/plugins/daterangepicker/daterangepicker.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('adminlte/plugins/datepicker/datepicker3.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('leftside_extra'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="main-box row">
    <h3 class="exc-title"><?php echo e($item->title); ?></h3>

    <?php if(count($item->price)>0): ?>
    <div class="row">
        <div class="col-md-6">
            <div class="row">
                <div class="col-md-12">
                    <img src="<?php echo e(asset('images/price.png')); ?>" style="width: 74px; height: 36px; margin-top: 10px;" alt="" />
                </div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <h4 class="box-title"><?php echo e(ucfirst($item->price->st_name)); ?></h4>

                </div>
                <div class="col-md-6">
                    <?php echo e($item->price->st_price); ?> <?php echo e(Vars::getVar("currency")); ?>

                </div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <h4 class="box-title"><?php echo e(ucfirst($item->price->sec_name)); ?></h4>
                </div>
                <div class="col-md-6">
                    <?php echo e($item->price->sec_price); ?>  <?php echo e(Vars::getVar("currency")); ?>

                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
    <div class="row">
        <div class="col-md-12">
            <div id="exc-label"> <?php echo e(Vars::getVar("introduction")); ?></div>
            <?php echo e($item->intro); ?>

        </div>
    </div>
    <div class="row">
        <div class="col-md-12">

            <?php if(count($item->exploration)>0): ?>
            <div id="exc-label"> <?php echo e(vars::getVar("explanation")); ?></div>
            <?php $__currentLoopData = $item->exploration; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exploration): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <div id="details-cover" class="row">
                <div id="details">
                    <div class="first">
                        <P>
                            <?php if(!is_null($exploration->ended_at)): ?>
                            <?php echo e(date('h:i',strtotime($exploration->ended_at))); ?>

                            <?php endif; ?>
                        </p>
                    </div>
                    <div class="second">
                        <?php echo e($exploration->txt); ?>

                    </div>
                    <img src="<?php echo e(asset('images/gallery/thumb/'.$exploration->img)); ?>" width="159" height="118" /> </div>
            </div>


            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            <?php endif; ?>
            <!-- Inclusion -->
            <?php if(count($item->inclusion)>0): ?>
            <div id="exc-label"> <?php echo e(vars::getVar("inclusion")); ?></div>
            <ul class="tour-details">
                <?php $__currentLoopData = $item->inclusion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inclusion): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <li><?php echo e($inclusion->txt); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </ul>
            <?php endif; ?>
            <!-- Inclusion -->
            <!-- Exclusion -->
            <?php if(count($item->exclusion)>0): ?>
            <div id="exc-label"> <?php echo e(vars::getVar("exclusion")); ?></div>
            <ul class="tour-details">
                <?php $__currentLoopData = $item->exclusion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exclusion): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <li><?php echo e($exclusion->txt); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </ul>
            <?php endif; ?>
            <!-- Exclusion -->
            <!-- additional -->
            <?php if(count($item->additional)>0): ?>
            <div id="exc-label"> <?php echo e(vars::getVar("additional")); ?></div>
            <ul class="tour-details">
                <?php $__currentLoopData = $item->additional; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $additional): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <li><?php echo e($additional->txt); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </ul>
            <?php endif; ?>
            <!-- additional -->
            <!-- Dresses -->
            <?php if(count($item->dresse)>0): ?>
            <div id="exc-label"> <?php echo e(vars::getVar("dresses")); ?></div>
            <ul class="tour-details">
                <?php $__currentLoopData = $item->dresse; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dresse): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <li><?php echo e($dresse->txt); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </ul>
            <?php endif; ?>
            <!-- Dresses -->
            <!-- availability -->
            <?php if(count($item->detail)>0): ?>
            <div id="exc-label"> <?php echo e(vars::getVar("availability")); ?></div>
            <ul class="tour-details">
                <?php $__currentLoopData = unserialize($item->detail->availability); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $availability): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <li><?php echo e(vars::getVar($availability)); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </ul>
            <?php endif; ?>
            <!-- availability -->
            <!-- notes -->
            <?php if(count($item->note)>0): ?>
            <div id="exc-label"> <?php echo e(vars::getVar("note")); ?></div>
            <ul class="tour-details">
                <?php $__currentLoopData = $item->note; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <li><?php echo e($note->txt); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </ul>
            <?php endif; ?>
            <!-- notes -->

        </div>
    </div>


    <div class="row">
        <div class="col-md-8">
            <div id="listing_form">
                <form action="<?php echo e(route('add.to.cart',['id'=>$item->id])); ?>" method="post">
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"
                           <input type="hidden" name="item_id" value="<?php echo e($item->id); ?>"/>
                    <div class="form-group">
                        <div class="label one"> <?php echo e(vars::getVar("select_date")); ?></div>
                    </div>
                    <div class="form-group <?php echo e($errors->has('date')?'has-error':''); ?>">
                        <div class="input-group">
                            <div class="input-group-addon">
                                <i class="fa fa-calendar"></i>
                            </div>
                            <input name="date" type="text" class="form-control" data-inputmask="'alias': 'dd/mm/yyyy'" data-mask>
                        </div>
                        <?php if($errors->has('date')): ?>
                        <span class="help-block">The Date is Required</span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <div class="label tow"> <?php echo e(vars::getVar("travelers_number")); ?></div>
                    </div>
                    <div class="row">
                        <div class="col-md-3 col-xs-3">
                            <h4 class="box-title"><?php echo e(vars::getVar("adult")); ?></h4>
                        </div>
                        <div class="col-md-3 col-xs-3">
                            <div class="form-group">

                                <select name="st_no" class="form-control" style="width: 100%;">
                                    <?php for($i=1;$i<10;$i++): ?>
                                    <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                                    <?php endfor; ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-3 col-xs-3">
                            <h4 class="box-title"><?php echo e(vars::getVar("child")); ?></h4>
                        </div>
                        <div class="col-md-3 col-xs-3">
                            <div class="form-group">

                                <select name="sec_no" class="form-control" style="width: 100%;">
                                    <?php for($i=0;$i<10;$i++): ?>
                                    <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                                    <?php endfor; ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div id="listing_field">
                        <input  type="submit" value="" />
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <?php if(count($item->privates)>0): ?>
            <table class="table table-bordered" style="background-color: #FFF;">
                <thead>
                    <tr>
                        <th></th>
                        <th>1 Pax</th>
                        <th>2 Pax</th>
                        <th>3 Pax</th>
                        <th>4-9 Pax</th>
                        <th>10-18 Pax</th>
                        <th>18-45 Pax</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $item->privates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $private): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <tr>
                        <td><?php echo e($private->sort); ?></td>
                        <td><?php echo e($private->pax_1); ?></td>
                        <td><?php echo e($private->pax_2); ?></td>
                        <td><?php echo e($private->pax_3); ?></td>
                        <td><?php echo e($private->pax_4); ?></td>
                        <td><?php echo e($private->pax_10); ?></td>
                        <td><?php echo e($private->pax_18); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </tbody>
            </table>
            <?php endif; ?>
        </div>
    </div>


    <?php if(count($errors)>0): ?>
    <div class="alert alert-danger alert-dismissible">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <h4><i class="icon fa fa-ban"></i> Alert!</h4>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>
</div><?php $__env->stopSection(); ?>
<?php $__env->startSection('_extra_js'); ?>
<!-- InputMask -->
<script src="<?php echo e(asset('adminlte/plugins/input-mask/jquery.inputmask.js')); ?>"></script>
<script src="<?php echo e(asset('adminlte/plugins/input-mask/jquery.inputmask.date.extensions.js')); ?>"></script>
<script src="<?php echo e(asset('adminlte/plugins/input-mask/jquery.inputmask.extensions.js')); ?>"></script>
<script>
$(function() {
    //Datemask dd/mm/yyyy
    $("#datemask").inputmask("dd/mm/yyyy", {"placeholder": "dd/mm/yyyy"});
    //Datemask2 mm/dd/yyyy
    $("#datemask2").inputmask("mm/dd/yyyy", {"placeholder": "mm/dd/yyyy"});
    //Money Euro
    $("[data-mask]").inputmask();
});
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('Web.Layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>