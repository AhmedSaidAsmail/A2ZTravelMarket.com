<?php $__env->startSection('meta_tags'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<h1 class="all-tour-title"><?php echo e($attraction->name); ?> <span><?php echo e(count($items)); ?> activities found</span></h1>
<div class="row">
    <div class="col-md-3">
        <form method="get" action="<?php echo e(route('attraction.show.available',['id'=>$attraction->id])); ?>">
            <div class="left-side-form">
                <span class="form-header">
                    Enter your dates to find available activities:
                </span>
                <div class="form-group">
                    <div class="input-group sp-eddition">
                        <div class="input-group-addon">
                            <label>from</label>
                            <i class="fa fa-calendar-o fa-lg"></i>
                        </div>
                        <input name="from" type="text" class="form-control" id="tour_from">
                    </div>
                    <!-- /.input group -->
                </div>
                <div class="form-group">
                    <div class="input-group sp-eddition">
                        <div class="input-group-addon">
                            <label>to</label>
                            <i class="fa fa-calendar-o fa-lg"></i>
                        </div>
                        <input name="to" type="text" class="form-control" id="tour_to">
                    </div>
                    <!-- /.input group -->
                </div>
                <button class="btn btn-info btn-block">Check Availability</button>
            </div> 
        </form>

    </div>
    <div class="col-md-9">
        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        <a href="<?php echo e(route('tour.show',['city'=>$attraction->sort->name,'tour'=>$item->name,'id'=>$item->id])); ?>" class="item-tour-link">
            <div class="row item-tour" id="item-tour">
                <div class="col-md-4">
                    <div class="item-tour-img">
                        <img src="<?php echo e(asset('images/items/thumb/'.$item->img)); ?>" class="img-abs-center" alt="<?php echo e($item->name); ?>">
                    </div>
                </div>
                <div class="col-md-8 item-tour-right">
                    <div class="tour-price-from"><span><?php echo e(Vars::getVar('From')); ?></span>
                        <?php echo \App\Http\Controllers\Web\ItemsController::getLowestPrice2($item->id); ?></div>
                    <div class="tour-duration">
                        <i class="fa fa-clock-o"></i> <label><?php echo e(Vars::getVar('Duration')); ?>:</label> <?php echo e($item->duration); ?> <?php echo e(Vars::getVar('hours')); ?>

                    </div>
                    <h2><?php echo e($item->name); ?><?php echo e($item->id); ?></h2>
                    <div class="item-tour-rating">
                        <?php echo e(App\Http\Controllers\ReviewController::getRateStar(App\Http\Controllers\ReviewsRateCalculate::calc($item->id,'overall_rating'))); ?>

                        <?php echo e(count($item->reviews()->where('confirm',1)->get())); ?> <?php echo e(Vars::getVar('Reviews')); ?>

                    </div>
                    <span class="item-tour-intro">
                        <?php echo \Illuminate\Support\Str::limit($item->intro, $limit = 147, $end = '...'); ?>

                    </span>
                </div>
            </div>
        </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        <div class="row text-center see-all">
            <button class="btn btn-info" id="show-more" data-start="10">Show <span>10</span> more activities</button>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('_extra_css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/datepicker/zebra_datepicker.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('_extra_js'); ?>
<script type="text/javascript" src="<?php echo e(asset('js/datepicker/zebra_datepicker.min.js')); ?>"></script>
<script>
$('#tour_from').Zebra_DatePicker({
    direction: true,
    format: 'Y-m-d',
    default_position: 'below',
    pair: $('#tour_to'),
    onSelect: function () {
        var label = $(this).closest('.input-group').find('label');
        label.addClass('small');
        $('#tour_to').trigger('click');
    }
});
$('#tour_to').Zebra_DatePicker({
    direction: true,
    format: 'Y-m-d',
    default_position: 'below',
    onSelect: function () {
        var label = $(this).closest('.input-group').find('label');
        label.addClass('small');
    }
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Web.Layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>