<?php $__env->startSection('title','Category Panel | Update'); ?>
<?php $__env->startSection('Extra_Css'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/admin/style.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <!-- Directory&Header -->
    <section class="content-header">
        <h1>Categories <small>Categories Update</small> </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> C-Panel</a></li>
            <li><a href="#">Update Category : <?php echo e($Sort->name); ?></a></li>
        </ol>
    </section>
    <!-- end Directory&Header -->
    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-xs-12">
                <!-- box -->
                <div class="box">
                    <div class="box-header with-border">
                        <div class="form-group">
                            <button type="submit" class="form-control btn-primary" >Update Catagory : (<?php echo e($Sort->name); ?>)</button>
                        </div>
                    </div>

                    <form method="post" action="<?php echo e(route('Category.update',['id'=>$Sort->id])); ?>" enctype="multipart/form-data">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <input type="hidden" name="_method" value="PUT">
                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group <?php echo e(($errors->has('basicsort_id'))?'has-error':''); ?>">
                                        <label>Main Category Name:</label>
                                        <select class="form-control" name="basicsort_id">
                                            <option value="">Select Main Category</option>
                                            <?php $__currentLoopData = App\MyModels\Admin\Basicsort::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $MainCategory): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                            <option value="<?php echo e($MainCategory->id); ?>" <?php echo ($MainCategory->id==$Sort->basicsort_id)?'selected="selected"':''; ?>><?php echo e($MainCategory->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Category Name:</label>
                                        <input class="form-control" value="<?php echo e($Sort->name); ?>" name="name" placeholder="Main category Name" required>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Category Title:</label>
                                        <input class="form-control" value="<?php echo e($Sort->title); ?>" name="title" placeholder="Main category Title" required>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label>Icon</label>
                                        <select name="icon" class="form-control">
                                            <option value="">Select</option>
                                            <option value="fa-university" <?php echo ($Sort->icon=='fa-university')?'selected="selected"':''; ?>> university</option>
                                            <option value="fa-eye" <?php echo ($Sort->icon=='fa-eye')?'selected="selected"':''; ?>> eye</option>
                                            <option value="fa-anchor" <?php echo ($Sort->icon=='fa-anchor')?'selected="selected"':''; ?>> anchor</option>
                                            <option value="fa-sun-o" <?php echo ($Sort->icon=='fa-sun-o')?'selected="selected"':''; ?>> sun</option>
                                            <option value="fa-picture-o" <?php echo ($Sort->icon=='fa-picture-o')?'selected="selected"':''; ?>> picture</option>
                                            <option value="fa-heart" <?php echo ($Sort->icon=='fa-heart')?'selected="selected"':''; ?>> heart</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-5">
                                    <div class="form-group">
                                        <label>First Slogan</label>
                                        <input type="text" value="<?php echo e($Sort->slogan); ?>" name="slogan" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-5">
                                    <div class="form-group">
                                        <label>Second Slogan</label>
                                        <input type="text" value="<?php echo e($Sort->slogan2); ?>" name="slogan2" class="form-control">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Status</label>
                                        <select class="form-control" name="status">
                                            <option value="1" >Show</option>
                                            <option value="0" <?php echo (! $Sort->status)?'selected="selected"':''; ?>>Hidden</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Home Shortcut</label>

                                        <select class="form-control" name="recommended">
                                            <option value="1">Show</option>
                                            <option value="0" <?php echo (! $Sort->recommended)?'selected="selected"':''; ?>>Hidden</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group <?php echo e($errors->has('arrangement')?'has-error':''); ?>">
                                        <label>Arrangment</label>
                                        <input  value="<?php echo e($Sort->arrangement); ?>" name="arrangement" class="form-control">
                                        <?php if($errors->has('arrangement')): ?>
                                        <span class="help-block">The Arrangment has to be Integer</span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group <?php echo e($errors->has('img')?'has-error':''); ?>">
                                        <label>Image</label>
                                        <input type="file" class="form-control" name="img">
                                        <?php if($errors->has('img')): ?>
                                        <span class="help-block">It has to be an Image File</span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Keywords:</label>
                                        <input class="form-control" value="<?php echo e($Sort->keywords); ?>" name="keywords" placeholder="-- Keywords --" >
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Description:</label>
                                        <input class="form-control" value="<?php echo e($Sort->description); ?>" name="description" placeholder="-- Description --" >
                                    </div>
                                </div>
                            </div>
                            <div class="form-group"> <input type="submit" class="btn btn-primary" value="Edit Main Category"></div>
                            <div class="form-group"> </div>
                        </div>
                    </form>

                </div>
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </section>
    <!-- end content -->
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('Extra_Js'); ?>
<script src="<?php echo e(asset('js/admin/admin.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.Layouts.Layout_Basic', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>