<?php $__env->startSection('content'); ?>
<div class="main-box row">
    <div class="booking_method row">
        <div class="col-md-4 first-method"> <span><?php echo e(Vars::getVar('Add_to_cart')); ?></span></div>
        <div class="col-md-4 second-methode"> <span><?php echo e(Vars::getVar('Review_order')); ?></span></div>
        <div class="col-md-4 third-methode"> <span><?php echo e(Vars::getVar('Secure_checkout')); ?></span></div>
    </div>
    <div id="list_refrence">
        <div class="left">
            <h1><?php echo e(Vars::getVar('Review_your_order')); ?></h1>
            <div> <?php echo e(Vars::getVar('Items_in_cart')); ?>: <?php echo e(Session::has('cart')?Session::get('cart')->totalQty:0); ?></div>
        </div>
        <div class="right">
            <div> <?php echo e(Vars::getVar('Current_cart_total')); ?> </div>
            <h1><span><?php echo e(Vars::getVar('Currency_label')); ?></span><?php echo e($total); ?></h1>
        </div>
    </div>
    <div id="trip_listing">
        <?php if(isset($items)): ?>
        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        <div id="trip_item" class="row">
            <div class="col-md-8 col-xs-8 cart-item-left">
                <h1><?php echo e(App\MyModels\Admin\Item::find($key)->title); ?> </h1>
                <div class="row">
                    <div class="col-md-5 col-xs-5">
                        <img src="<?php echo e(asset('images/items/thumb/'.App\MyModels\Admin\Item::find($key)->img)); ?>" />
                    </div>
                    <div class="col-md-7 col-xs-7">
                        <div> <span><?php echo e(Vars::getVar('Travel_date')); ?>:</span> <?php echo e($item['date']); ?></div>
                        <div> <span><?php echo e(Vars::getVar('Number_of_Adult')); ?>:</span> <?php echo e($item['st_no']); ?></div>
                        <div> <span><?php echo e(Vars::getVar('Number_of_Child')); ?>:</span> <?php echo e($item['sec_no']); ?></div>
                        <a href="<?php echo e(route('remove.from.cart',['id'=>$key])); ?>" id="remove-cart-item"><i class="fa fa-trash" aria-hidden="true"></i><?php echo e(Vars::getVar('remove')); ?></a>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-xs-4 cart-item-right">
                <h1><span>&euro;</span><?php echo e($item['price']); ?></h1>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        <?php endif; ?>

    </div>
    <div id="listing_next">
        <div class="left"> <a href="index.php"><?php echo e(Vars::getVar('Continue_shopping')); ?></a></div>
        <div class="right"> <a href="<?php echo e(route('Web.checkout')); ?>"> <img src="images/proceed2checkout.png" /></a></div>
    </div>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('Web.Layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>