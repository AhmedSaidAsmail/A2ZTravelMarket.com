<?php $__env->startSection('meta_tags'); ?>
<?php $meta = App\MyModels\Admin\Topic::where('name', 'Home')->first() ?>
<meta name="keywords" content="<?php echo e($meta->keywords); ?>" />
<meta name="description" content="<?php echo e($meta->description); ?>" />
<title><?php echo e($meta->title); ?></title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header-nav'); ?>

<?php echo $__env->make('Web.Layouts.MainMenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="row" style="position: relative;">
    <div id="myCarousel" class="carousel slide" data-ride="carousel">
        <div class="carousel-inner">
            <div class="item active">
                <img src="<?php echo e(asset('images/flash/flash1.jpg')); ?>" alt="Pyramids">
            </div>
            <div class="item">
                <img src="<?php echo e(asset('images/flash/flash2.jpg')); ?>" alt="Luxor">
            </div>
            <div class="item">
                <img src="<?php echo e(asset('images/flash/flash3.jpg')); ?>" alt="Sphnix">
            </div>
            <div class="item">
                <img src="<?php echo e(asset('images/flash/flash4.jpg')); ?>" alt="Luxor">
            </div>
        </div>
        <!-- Left and right controls -->
        <a class="left carousel-control" href="#myCarousel" data-slide="prev" style="background-image: none;" >
            <span class="glyphicon glyphicon-chevron-left"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="right carousel-control" href="#myCarousel" data-slide="next" style="background-image: none;">
            <span class="glyphicon glyphicon-chevron-right"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>
    <div class="search-top-sliders row">
        <div class="row">
            <div class="col-md-12 search-top-insider">
                <div class="row" style="position: relative;">
                    <img src="images/lets-go.png" alt="let's go Hurghada Wonders" class="search-logo">
                    <span class="search-slogan"><?php echo e(Vars::getVar('the_activities_begin')); ?> <i class="fa fa-heart-o" aria-hidden="true"></i></span>
                </div>
                <form action="<?php echo e(route('Web.searchItems')); ?>" method="get" id="serach-items-result">
                    <div class="row search-form">
                        <div class="col-md-10">
                            <div class="form-group" style="position: relative;">
                                <input type="text" value="" class="form-control" id="welcome-search" placeholder="Search for destentions, attractions and tours">
                                <div class="welcome-search-result" id="search-result">
                                    <!-- search Result -->
                                </div>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <button type="submit" class="btn btn-info btn-block"><?php echo e(Vars::getVar('LETS_GO')); ?></button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- real insider -->
<div class="row welcome-conatiner">
    <div class="container">
        <div class="home-title">
            <div class="row-title"><?php echo e(Vars::getVar('TOP_EXCURSIONS_IN')); ?> <span><?php echo e(Vars::getVar('HURGHADA')); ?></span>
            </div>
            <div class="row-line"></div>

        </div>
        <div class="row">
            <?php $__currentLoopData = $items->slice(0,4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topItems): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <a href="<?php echo e(route('tour.show',['city'=>urlencode($topItems->sort->name),'tour'=>urlencode($topItems->name),'id'=>$topItems->id])); ?>">
                <div class="col-md-3">
                    <div class="welcome-exc-item">
                        <div class="welcome-exc-img">
                            <img src="<?php echo e(asset('images/items/thumb/'.$topItems->img)); ?>" alt="<?php echo e($topItems->title); ?>">
                            <div class="welcome-rating">
                                <span>5</span>
                                <i class="fa fa-star st-star"></i>
                                <i class="fa fa-star sec-star"></i>
                            </div>
                            <div class="welcome-price"><?php echo e(Vars::getVar('£')); ?>

                                <?php if(isset($topItems->price)): ?>
                                <?php echo e(sprintf('%.2f',$topItems->price->st_price)); ?>

                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="welcome-exc-info">
                            <h1><?php echo e($topItems->name); ?> </h1>
                            <p>
                                <?php echo e(str_limit($topItems->intro, $limit = 100, $end = '...')); ?>

                                <i class="fa fa-arrow-right" aria-hidden="true"></i>
                            </p>
                        </div>

                    </div>
                </div>
            </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

        </div>
        <div class="row" style="margin-top: 20px; margin-bottom: 20px;">
            <div class="col-md-8" style="padding-right: 0px;">
                <div class="home-title">
                    <div class="row-title"><?php echo e(Vars::getVar('FIND_MORE')); ?>  <span><?php echo e(Vars::getVar('EXCURSIONS')); ?></span>
                    </div>
                    <div class="row-line"></div>
                </div>
                <!-- exc Items Sector -->
                <?php $__currentLoopData = $items->slice(4,7); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <div class="row exc-items">
                    <div class="col-md-4">
                        <div class="exc-item-img">
                            <div class="exc-item-img-container">
                                <img src="<?php echo e(asset('images/items/thumb/'.$item->img)); ?>" alt="<?php echo e($item->title); ?>" class="img-abs-center">
                            </div>
                            <span class="fa fa-caret-left fa-4x"></span>
                            <div class="exc-img-shadow"></div>
                        </div>
                    </div>
                    <div class="col-md-8 exc-item-info">
                        <div class="row">
                            <div class="col-md-12">
                                <h2><?php echo e($item->name); ?></h2>
                                <span class="exc-item-duration"><i class="fa fa-clock-o fa-lg" aria-hidden="true"></i>
                                    <label><?php echo e(Vars::getVar('Duration')); ?>:</label>
                                    <?php echo isset($item->detail)?$item->detail->duration:0; ?>

                                    <?php echo e(Vars::getVar('hours')); ?></span>
                                <p>
                                    <?php echo e(str_limit($item->intro, $limit = 100, $end = '...')); ?>

                                </p>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 text-right">
                                <button class="btn btn-warning" style="width: 60%; background-color: #ffd924; border: 1px solid #ffd924;">
                                    <?php if(isset($item->price)): ?>
                                    <?php echo e(Vars::getVar('£')); ?><?php echo e(sprintf('%.2f',$item->price->st_price)); ?>

                                    <?php endif; ?>
                                </button>
                            </div>
                            <div class="col-md-6">
                                <a href="<?php echo e(route('tour.show',['city'=>urlencode($item->sort->name),'tour'=>urlencode($item->name),'id'=>$item->id])); ?>" class="btn btn-warning">
                                    <i class="fa fa-shopping-cart fa-lg" aria-hidden="true"></i> <?php echo e(Vars::getVar('Add_to_Basket')); ?>

                                </a>
                            </div>
                        </div>

                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                <!-- esc Items sector end -->
            </div>
            <div class="col-md-4" style="padding-left: 30px;">
                <?php echo $__env->make('Web.Layouts.rightSide', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Web.Layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>