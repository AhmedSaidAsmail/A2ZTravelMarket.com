<?php //echo "<pre>" . print_r(Session::all(), true)                         ?>

<?php $__env->startSection('title','Items Panel'); ?>
<?php $__env->startSection('Extra_Css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('adminlte/plugins/datatables/dataTables.bootstrap.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/admin/style.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <!-- Directory&Header -->
    <section class="content-header">
        <h1> Items <small>Items tables</small> </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> C-Panel</a></li>
            <li><a href="#">Items</a></li>
        </ol>
    </section>
    <!-- end Directory&Header -->
    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-xs-12">
                <!-- box -->
                <div class="box">
                    <div class="box-header with-border">
                        <div class="form-group">
                            <button type="submit" class="btn btn-block btn-danger" id="addNew"><i class="fa fa-bicycle fa-lg"></i> Add New Activity</button>
                        </div>
                        <?php if(session('success')): ?>
                        <div class="alert alert-success alert-dismissible">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <h4><i class="icon fa fa-ban"></i> <?php echo e(session('success')); ?> </h4>
                        </div>
                        <?php endif; ?>
                        <?php if(session('failure')): ?>
                        <div class="alert alert-danger alert-dismissible">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <h4><i class="icon fa fa-ban"></i> <?php echo e(session('failure')); ?> </h4>
                        </div>
                        <?php endif; ?>
                        <?php if(count($errors)>0): ?>
                        <div class="alert alert-danger alert-dismissible">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <h4><i class="icon fa fa-ban"></i> Alert!</h4>
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            </ul>
                        </div>
                        <?php elseif(Session::has('deleteStatus')): ?>
                        <div class="alert alert-success alert-dismissible">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <h4><i class="icon fa fa-check"></i> Alert!</h4>
                            <?php echo e(Session('deleteStatus')); ?>

                        </div>
                        <?php elseif(Session::has('fetchData')): ?>
                        <div class="alert alert-danger alert-dismissible">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <h4><i class="icon fa fa-check"></i> Alert!</h4>
                            <?php echo e(Session('fetchData')); ?>

                        </div>
                        <?php endif; ?>
                    </div>
                    <div id="basicToggle">
                        <form method="post" action="<?php echo e(route('suItems.store')); ?>" enctype="multipart/form-data">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <input type="hidden" value="<?php echo e(Auth::user()->id); ?>" name="supplier_id">
                            <div class="box-body">
                                <div class="row">
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label>Attraction Name:</label>
                                            <select class="form-control" name="attraction_id">
                                                <option value="">Select an Attraction</option>
                                                <?php $__currentLoopData = \App\Models\Attraction::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                                <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?> ( <?php echo e($category->sort->name); ?>/<?php echo e($category->sort->basicsort->name); ?> )</option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label>Tour Name:</label>
                                            <input class="form-control" name="name" placeholder="Eg: Cairo by bus from sharm el sheikh" required>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label>Tour page title:</label>
                                            <input class="form-control" name="title" placeholder="Eg: Amazing Trip To Cairo" required>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label>Cancellation policy: in days</label>
                                            <input type="number" class="form-control" name="cancellation" value="1" min="0"  required>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">

                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label>Image</label>
                                            <input type="file" class="form-control" name="img">
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label>Duration:</label>
                                            <input type="number" class="form-control" name="duration" placeholder="only number" required>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label>Keywords:</label>
                                            <input class="form-control" name="keywords" placeholder="-- Keywords --" >
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label>Description:</label>
                                            <input class="form-control" name="description" placeholder="-- Description --" >
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label>Intro</label>
                                            <textarea class="form-control" name="intro"></textarea>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group"> 
                                    <button class="btn btn-danger"><i class="fa fa-bicycle"></i> Add the new Tour</button>
                                </div>
                                <div class="form-group"> </div>
                            </div>
                        </form>
                    </div>
                </div>
                <!-- end box 1 -->
                <!-- /.box -->
                <div class="box">
                    <div class="box-header">
                        <h3 class="box-title">Activities Data With Full Features</h3>
                    </div>
                    <!-- /.box-header -->
                    <div class="box-body">
                        <table id="example1" class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>City</th>
                                    <th>Attraction</th>
                                    <th>Tour</th>
                                    <th>Visitors</th>
                                    <th>Reviews</th>
                                    <th>Rating</th>
                                    <th>Status</th>
                                    <th>Reservations</th>
                                    <th>Recommended</th>
                                    <th>#Action</th>
                                </tr>
                            </thead>
                            <tbody>

                                <?php $__currentLoopData = Auth::user()->items()->where('deleted',0)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <tr>
                                    <td><?php echo e($Item->attraction->sort->name); ?></td>
                                    <td><?php echo e($Item->attraction->name); ?></td>
                                    <td><?php echo e($Item->name); ?></td>
                                    <td><?php echo e($Item->visits); ?></td>
                                    <td><?php echo e($Item->reviews()->count()); ?></td>
                                    <td><?php echo e(\App\Http\Controllers\ReviewsRateCalculate::calc($Item->id,'overall_rating',"all")); ?></td>
                                    <td> <?php if($Item->status): ?> <i class="fa fa-circle text-green"></i> <?php else: ?> <i class="fa fa-circle text-gray"></i> <?php endif; ?> </td>
                                    <td><?php echo e($Item->tours()->count()); ?></td>
                                    <td> <?php if($Item->recommended): ?> <i class="fa fa-circle text-green"></i> <?php else: ?> <i class="fa fa-circle text-gray"></i> <?php endif; ?> </td>
                                    <td><div class="btn-group">
                                            <button type="button" class="btn btn-default">Action</button>
                                            <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown"> <span class="caret"></span> <span class="sr-only">Toggle Dropdown</span> </button>
                                            <ul class="dropdown-menu" role="menu">
                                                <li><a href="<?php echo e(route('suItems.edit',['id'=>$Item->id])); ?>">Change</a></li>

                                                <form action="<?php echo e(route('suItems.destroy',['id'=>$Item->id])); ?>" method="post">
                                                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                                    <input type="hidden" name="_method" value="DELETE">
                                                    <li><a class="deleteItem list-group-item" href="#" title="<?php echo e($Item->name); ?>">Delete</a></li>
                                                </form>
                                            </ul>
                                        </div></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            </tbody>

                            <tfoot>
                                <tr>
                                    <th>City</th>
                                    <th>Attraction</th>
                                    <th>Tour</th>
                                    <th>Visitors</th>
                                    <th>Reviews</th>
                                    <th>Rating</th>
                                    <th>Status</th>
                                    <th>Reservations</th>
                                    <th>Recommended</th>
                                    <th>#Action</th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('Extra_Js'); ?>
<script src="<?php echo e(asset('js/admin/admin.js')); ?>"></script>
<script src="<?php echo e(asset('adminlte/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('adminlte/plugins/datatables/dataTables.bootstrap.min.js')); ?>"></script>
<script>
$(function () {
    $("#example1").DataTable();
    $('#example2').DataTable({
        "paging": true,
        "lengthChange": false,
        "searching": false,
        "ordering": true,
        "info": true,
        "autoWidth": false
    });
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Supplier.Layouts.Layout_Basic', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>