<?php $__env->startSection('meta_tags'); ?>
<title><?php echo e($category->title); ?></title>
<meta name="keywords" content="<?php echo e($category->keywords); ?>">
<meta name="description" content="<?php echo e($category->description); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row exc-container">
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <div class="row">
                    <div class="col-md-12 exc-item-img">
                        <img src="<?php echo e(asset('images/sorts/'.$category->img)); ?>" alt="">
                    </div>
                </div>
                <div class="row" >
                    <div class="col-md-12 exc-item-img-title">
                        <h3><span class="glyphicon glyphicon-briefcase"></span> <?php echo e($category->title); ?></h3>
                    </div>

                </div>
                <div class="row exc-items-conatiner">
                    <?php $__currentLoopData = $category->items->where('status',"=",1)->chunk(2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunks): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <div class="row welcome-items">
                        <?php $__currentLoopData = $chunks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <div class="col-md-6" >
                            <div class="welcome-item">
                                <div class="welcome-item-img-container">
                                    <a href="<?php echo e(route('tour.show',['city'=>urlencode($category->name),'tour'=>urlencode($item->name),'id'=>$item->id])); ?>">
                                        <img src="<?php echo e(asset('images/items/'.$item->img)); ?>"  alt="<?php echo e($item->title); ?>" style="width: 100%;">
                                    </a>
                                    <div class="thumb-one orange-thumb">
                                        <?php if(isset($item->price)): ?>
                                        <?php echo e(sprintf('%.2f',$item->price->st_price)); ?>

                                        <?php endif; ?>
                                        <span class="price-currency-label"><?php echo e(Vars::getVar("$")); ?></span>
                                    </div>
                                </div>

                                <div class="welcome-item-txt-container">
                                    <div class="welcome-img-border">
                                        <span class="glyphicon glyphicon-triangle-top"></span>
                                    </div>
                                    <h2><?php echo e($item->name); ?></h2>
                                    <?php
                                    echo substr($item->intro, 0, 130);
                                    ?>

                                    ...<a href="<?php echo e(route('tour.show',['city'=>urlencode($category->name),'tour'=>urlencode($item->name),'id'=>$item->id])); ?>">Read More</a>

                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>


                </div>

            </div>
            <div class="col-md-4">
                <div class="row transfer-form">
                    <div class="col-md-12 text-center transfer-form-header">
                        <h3 class="text-center" style="width: 50%; margin: 0 auto;">
                            <i class="fa fa-car" aria-hidden="true"></i> SHARM TRANSFER</h3>
                        easy booking

                    </div>
                    <div class="transfer-form-body">
                        <div class="row" style="padding-top: 75px;">
                            <div class="col-md-6">

                                <div class="form-group">
                                    <label>Arrival Date</label>

                                    <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-calendar"></i>
                                        </div>
                                        <input type="text" class="form-control" data-inputmask="'alias': 'dd/mm/yyyy'" data-mask>
                                    </div>
                                    <!-- /.input group -->
                                </div>



                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Departure Date</label>

                                    <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-calendar"></i>
                                        </div>
                                        <input type="text" class="form-control" data-inputmask="'alias': 'dd/mm/yyyy'" data-mask>
                                    </div>
                                    <!-- /.input group -->
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>From</label>
                                    <select class="form-control select2" style="width: 100%;">
                                        <option selected="selected">Select Destination</option>
                                        <option>Alaska</option>
                                        <option>California</option>
                                        <option>Delaware</option>
                                        <option>Tennessee</option>
                                        <option>Texas</option>
                                        <option>Washington</option>
                                    </select>
                                </div>

                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>To</label>
                                    <select class="form-control select2" style="width: 100%;">
                                        <option selected="selected">Select Destinations</option>
                                        <option>Alaska</option>
                                        <option>California</option>
                                        <option>Delaware</option>
                                        <option>Tennessee</option>
                                        <option>Texas</option>
                                        <option>Washington</option>
                                    </select>
                                </div>

                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Transfer Type</label>
                                    <select class="form-control select2" style="width: 100%;">
                                        <option selected="selected">Select Destination</option>
                                        <option>Alaska</option>
                                        <option>California</option>
                                        <option>Delaware</option>
                                        <option>Tennessee</option>
                                        <option>Texas</option>
                                        <option>Washington</option>
                                    </select>
                                </div>

                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>One-Way/Return</label>
                                    <select class="form-control select2" style="width: 100%; border: 1px solid #fe6500;">
                                        <option selected="selected">Select Destinations</option>
                                        <option>Alaska</option>
                                        <option>California</option>
                                        <option>Delaware</option>
                                        <option>Tennessee</option>
                                        <option>Texas</option>
                                        <option>Washington</option>
                                    </select>
                                </div>

                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Flight NO</label>
                                    <input type="text" name="flight-no" class="form-control">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Airline</label>
                                    <input type="text" name="airline" class="form-control">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12 transfer-text-label">
                                <i class="fa fa-info-circle" aria-hidden="true"></i> Please select the number of Adults and Children for transfer
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Adult</label>
                                    <input type="number" value="" name="adult" class="form-control">
                                </div>

                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Child</label>
                                    <input type="number" value="" name="adult" class="form-control">
                                </div>

                            </div>
                        </div>
                        <div class="row text-center">
                            <button class="btn btn-lg" style="margin-bottom: -25px; background-color: #fe6500; color: #FFF;">
                                <span class="glyphicon glyphicon-shopping-cart"></span> add to Basket <span class="glyphicon glyphicon-arrow-right"></span>
                            </button>
                        </div>
                    </div>
                </div>


                <div class="row">
                    <div class="col-md-12 youtube-holder">
                        <iframe id="youtube"  height="315" src="https://www.youtube.com/embed/jnfwoGw3fnU" frameborder="0" allowfullscreen></iframe>
                    </div>


                </div>

                <div class="row">
                    <h1><?php echo e($category->title); ?></h1>
                    <ul>
                        <?php $__currentLoopData = $category->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <li><a href=""><?php echo e($item->title); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                    </ul>
                </div>

            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-1"></div>
        <div class="col-md-10">
            <div class="row more-attractions">
                <h3>More Things to Do in Sharm el Sheikh</h3>
                <ul class="list-inline">
                    <?php $__currentLoopData = $Categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Seccategory): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <li><span><a href="<?php echo e(route('cities.show',['city'=>urlencode($Seccategory->name),'id'=>$Seccategory->id])); ?>"><?php echo e($Seccategory->title); ?></a></span></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </ul>
            </div>
            <div class="row more-attractions">
                <h3>Top Sharm el Sheikh Attractions</h3>
                <ul class="list-inline">
                    <?php $__currentLoopData = $Categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $LinkCategory): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <?php $__currentLoopData = $LinkCategory->items->where('recommended',"=",1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $LinkItems): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>

                    <li><span><a href=""><?php echo e($LinkItems->title); ?></a></span></li>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </ul>
            </div>
        </div>


    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Web.Layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>