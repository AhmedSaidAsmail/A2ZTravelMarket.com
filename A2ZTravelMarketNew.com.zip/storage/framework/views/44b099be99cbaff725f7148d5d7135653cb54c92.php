<?php $__env->startSection('meta_tags'); ?>
<title><?php echo e($item->title); ?></title>
<meta name="keywords" content="<?php echo e($item->keywords); ?>" />
<meta name="description" content="<?php echo e($item->description); ?>" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header-nav'); ?>
<?php echo $__env->make('Web.nav-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<!-- dynamic content -->
<div class="row intital-pages">
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <div class="row tour-short-details">
                    <h1><?php echo e($item->title); ?></h1>
                    <div class="col-md-7">

                        <div class="row item-tripadvisor-icon">
                            <div class="row">
                                <div class="col-md-3 col-lg-2 col-xs-3 col-sm-3" style="margin-top: 0px;">
                                    <div class="fb-like" data-href="http://www.hurghadawonders.com" data-layout="button_count" data-action="like" data-size="small" data-show-faces="false" data-share="false"></div>
                                </div>
                                <div class="col-md-3 col-lg-2 col-xs-3 col-sm-3">
                                    <a href="https://twitter.com/share" class="twitter-share-button" data-url="http://hurghadawonders.com" data-count="none">Tweet</a>
                                </div>
                                <div class="col-md-4 col-lg-3 google-api">
                                    <script src="https://apis.google.com/js/platform.js" async defer></script>
                                    <div class="g-follow" data-annotation="bubble" data-height="20" data-href="//plus.google.com/u/0/113067422417563827751" data-rel="publisher"></div>
                                </div>
                                <div class="col-md-2 col-xs-3 col-sm-3"><a href="//www.pinterest.com/pin/create/button/" data-pin-do="buttonBookmark"  data-pin-color="red"><img src="//assets.pinterest.com/images/pidgets/pinit_fg_en_rect_red_20.png" /></a>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <table class="table">
                                <tr>
                                    <td><?php echo e(Vars::getVar('Availability')); ?></td>
                                    <td>
                                        <?php if(isset($item->detail)): ?>
                                        <?php
                                        if (count(unserialize($item->detail->availability)) >= 7) {
                                            $days = Vars::getVar('every_day');
                                        } else {
                                            $days = implode(" , ", unserialize($item->detail->availability));
                                        }
                                        echo $days;
                                        ?>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <tr>
                                    <td><?php echo e(Vars::getVar('Pickup_Time')); ?></td>
                                    <td><?php echo e(isset($item->detail)?date('h:i A',strtotime($item->detail->started_at)):""); ?></td>
                                </tr>
                                <tr>
                                    <td><?php echo e(Vars::getVar('Return_Time')); ?></td>
                                    <td><?php echo e(isset($item->detail)?date('h:i A',strtotime($item->detail->ended_at)):""); ?></td>
                                </tr>
                                <tr>
                                    <td><?php echo e(Vars::getVar('Duration')); ?></td>
                                    <td><?php echo e(isset($item->detail)?$item->detail->duration:""); ?> <?php echo e(Vars::getVar('hours_approximately')); ?></td>
                                </tr>
                            </table>
                        </div>
                    </div>
                    <div class="col-md-5">
                        <div class="tour-details-img">
                            <img class="img-abs-center" src="<?php echo e(asset('images/items/'.$item->img)); ?>" alt="">
                        </div>

                    </div>
                </div>
                <!-- tour Details -->
                <div class="row item-details-container">



                    <ul class="nav nav-tabs item-details-tab">
                        <li class="active">
                            <a data-toggle="tab" href="#home"><span class="glyphicon glyphicon-stats" ></span> <?php echo e(Vars::getVar('Itinerary')); ?></a>
                        </li>
                        <li>
                            <a data-toggle="tab" href="#menu1"><span class="glyphicon glyphicon-picture"></span> <?php echo e(Vars::getVar('Gallery')); ?></a>
                        </li>

                    </ul>

                    <div class="tab-content item-tab-style" >
                        <div id="home" class="tab-pane fade in active">
                            <h3><?php echo e(Vars::getVar('Highlights')); ?></h3>
                            <h3><b><?php echo e($item->title); ?></b></h3>
                            <?php if(isset($item->exploration->txt)): ?>
                            <?php echo $item->exploration->txt; ?>

                            <?php endif; ?>
                            <div class="row small-gallery">
                                <div class="small-gallery-label">
                                    <span class="small-gallery-label-span">
                                        <span class="glyphicon glyphicon-picture"></span> <?php echo e(Vars::getVar('Small_Gallery')); ?></span>
                                </div>

                                <?php if(isset($item->itemsgallrie)): ?>
                                <?php $__currentLoopData = $item->itemsgallrie->slice(0,4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <div class="col-md-3">
                                    <div class="small-gallery-img">
                                        <a href="">
                                            <img class="img-abs-center" src="<?php echo e(asset('images/gallery/thumb/'.$img->img)); ?>" alt="<?php echo e($item->title); ?>">
                                        </a>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                <?php endif; ?>

                            </div>


                            <?php if(count($item->inclusion)>0): ?>
                            <div class="row">
                                <h3 class="item-details-label-header">
                                    <span class="fa-stack">
                                        <i class="fa fa-circle fa-stack-2x"></i>
                                        <i class="fa fa-check fa-stack-1x fa-inverse"></i>
                                    </span>
                                    <?php echo e(Vars::getVar('Our_Service_includes')); ?></h3>
                                <ul class="tour-multi-daetails">
                                    <?php $__currentLoopData = $item->inclusion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inclusion): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <li><?php echo e($inclusion->txt); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                </ul>
                            </div>
                            <?php endif; ?>
                            <?php if(count($item->exclusion)>0): ?>
                            <div class="row">
                                <h3 class="item-details-label-header">
                                    <span class="fa-stack">
                                        <i class="fa fa-circle fa-stack-2x"></i>
                                        <i class="fa fa-times fa-stack-1x fa-inverse"></i>
                                    </span> <?php echo e(Vars::getVar('Our_Service_Not_includes')); ?></h3>
                                <ul class="tour-multi-daetails">
                                    <?php $__currentLoopData = $item->exclusion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exclusion): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <li><?php echo e($exclusion->txt); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                </ul>
                            </div>
                            <?php endif; ?>

                            <?php if(count($item->additional)>0): ?>
                            <div class="row">
                                <h3 class="item-details-label-header">
                                    <span class="fa-stack">
                                        <i class="fa fa-circle fa-stack-2x"></i>
                                        <i class="fa fa-star fa-stack-1x fa-inverse"></i>
                                    </span> <?php echo e(Vars::getVar('Recommendation')); ?></h3>
                                <ul class="tour-multi-daetails">
                                    <?php $__currentLoopData = $item->additional; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $additional): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <li><?php echo e($additional->txt); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                </ul>
                            </div>
                            <?php endif; ?>
                            <div class="row">
                                <h3 class="item-details-label-header">
                                    <span class="fa-stack">
                                        <i class="fa fa-circle fa-stack-2x"></i>
                                        <i class="fa fa-info fa-stack-1x fa-inverse"></i>
                                    </span> <?php echo e(Vars::getVar('Do_you_need_more_details?_call_or_email_us')); ?></h3>
                                <ul class="tour-multi-daetails">
                                    <li><?php echo e(Vars::getVar('Phone')); ?></li>
                                    <li><?php echo e(Vars::getVar('email@email.com')); ?></li>
                                </ul>
                            </div>

                        </div>
                        <div id="menu1" class="tab-pane fade">
                            <h3>Menu 1</h3>
                            <p>Some content in menu 1.</p>
                        </div>

                    </div>
                </div>
                <!-- tour Deatils end -->
            </div>
            <!-- content right side -->
            <div class="col-md-4" style="padding-left: 30px;">
                <!-- booking form -->
                <?php echo $__env->make('Web.Layouts.BookingForm', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <!-- booking form end -->
                <?php echo $__env->make('Web.Layouts.rightSide', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            </div>
            <!-- content right side end -->
        </div>
    </div>
</div>
<!-- last Welcome start -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('extra-plugged-in'); ?>
<script>(function(d, s, id) {
    var js, fjs = d.getElementsByTagName(s)[0];
    if (d.getElementById(id))
        return;
    js = d.createElement(s);
    js.id = id;
    js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.9&appId=184060755364562";
    fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<script>!function(d, s, id) {
        var js, fjs = d.getElementsByTagName(s)[0], p = /^http:/.test(d.location) ? 'http' : 'https';
        if (!d.getElementById(id)) {
            js = d.createElement(s);
            js.id = id;
            js.src = p + '://platform.twitter.com/widgets.js';
            fjs.parentNode.insertBefore(js, fjs);
        }
    }(document, 'script', 'twitter-wjs');</script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('_extra_js'); ?>
<script type="text/javascript" src="<?php echo e(asset('js/datepicker/zebra_datepicker.min.js')); ?>"></script>
<script>

    var daysOff;
    var inputlink = $('.daysoff').attr('data');
    $.ajax({
        type: "get",
        url: inputlink,
        dataType: 'json',
        success: function(response) {

            daysOff = response;
            if (daysOff !== null) {
                $(function() {
                    $('#booking_date').Zebra_DatePicker({
                        direction: true,
                        format: 'Y-m-d',
                        default_position: 'below',
                        disabled_dates: ['* * * ' + daysOff]
                    });
                });
            } else {
                $(function() {
                    $('#booking_date').Zebra_DatePicker({
                        direction: true,
                        format: 'Y-m-d',
                        default_position: 'below'
                    });
                });
            }

        }
    });
</script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('_extra_css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/datepicker/zebra_datepicker.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Web.Layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>