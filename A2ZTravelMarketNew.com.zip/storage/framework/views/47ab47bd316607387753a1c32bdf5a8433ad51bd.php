<?php $__env->startSection('meta_tags'); ?>
<?php $meta = App\MyModels\Admin\Topic::where('name', 'transfer')->first() ?>
<?php if(!is_null($meta)): ?>
<meta name="keywords" content="<?php echo e($meta->keywords); ?>" />
<meta name="description" content="<?php echo e($meta->description); ?>" />
<title><?php echo e($meta->title); ?></title>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header-nav'); ?>
<?php echo $__env->make('Web.nav-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- content -->
<div class="transfer-banner">
    <img class="img-abs-center" src="<?php echo e(asset('images/majorca-airport-transfers.png')); ?>" alt="Easy Transfer">
</div>
<?php echo $__env->make('Web.Layouts.TransferInternalForm', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="row transfer-sorts">
    <?php if(isset($lowest_taxi)): ?>
    <div class="container">
        <div class="col-md-3 text-center transfer-sort limo-taxi">
            <span><?php echo e(Vars::getVar('Taxi')); ?></span>
            <?php echo e(Vars::getVar('from')); ?> <label><?php echo e(number_format($lowest_taxi->type_limousine,2)); ?><?php echo e(Vars::getVar("$")); ?></label>

        </div>
        <div class="col-md-3 text-center transfer-sort limo-van">
            <span><?php echo e(Vars::getVar('Minivan')); ?></span>
            <?php echo e(Vars::getVar('from')); ?> <label><?php echo e(number_format($lowest_van->type_van,2)); ?><?php echo e(Vars::getVar("$")); ?></label>
        </div>
        <div class="col-md-3 text-center transfer-sort limo-coaster">
            <span><?php echo e(Vars::getVar('Coaster')); ?></span>
            <?php echo e(Vars::getVar('from')); ?> <label><?php echo e(number_format($lowest_caoster->type_coaster,2)); ?><?php echo e(Vars::getVar("$")); ?></label>

        </div>
        <div class="col-md-3 text-center transfer-sort limo-bus">
            <span><?php echo e(Vars::getVar('Coach')); ?></span>
            <?php echo e(Vars::getVar('from')); ?> <label><?php echo e(number_format($lowest_bus->type_bus,2)); ?><?php echo e(Vars::getVar("$")); ?></label>
        </div>
    </div>
    <?php endif; ?>
</div>
<div class="row transfer-details">
    <div class="container">
        <?php $__currentLoopData = $transfers->chunk(2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        <div class="row">
            <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transfer): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <div class="col-md-6">
                <a href="<?php echo e(route('trnafsre.one',['id'=>$transfer->id])); ?>">
                    <div class="transfer-detail">
                        <?php echo e($transfer->dist_from); ?>

                        <span><?php echo e(Vars::getVar('from')); ?> <label>
                                <?php echo e(App\Http\Controllers\Web\TransferController::getLowestPrice($transfer->type_limousine,$transfer->type_van,$transfer->type_coaster,$transfer->type_bus)); ?>

                                <?php echo e(Vars::getVar("$")); ?></label></span>
                    </div>
                </a>

            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

    </div>
</div>
<!-- content end -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('_extra_css'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.11.2/moment.min.js"></script>
<link rel="stylesheet" href="<?php echo e(asset('adminlte/plugins/daterangepicker/daterangepicker.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('adminlte/plugins/select2/select2.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('_extra_js'); ?>
<script src="<?php echo e(asset('adminlte/plugins/select2/select2.full.min.js')); ?>"></script>
<!-- date Range -->
<script src="<?php echo e(asset('adminlte/plugins/daterangepicker/daterangepicker.js')); ?>"></script>
<script>
$(function () {
//Initialize Select2 Elements
    $(".select2").select2();
    $('#reservation').daterangepicker({
        startDate: new Date(),
        minDate: new Date()

    });


});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Web.Layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>