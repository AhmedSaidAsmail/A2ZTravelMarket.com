<?php $__env->startSection('title','Items Panel | Update'); ?>
<?php $__env->startSection('Extra_Css'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/admin/style.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('adminlte/plugins/select2/select2.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('adminlte/plugins/timepicker/bootstrap-timepicker.min.css')); ?>">
<style>
    td.pricetable{
        padding-top: 0px;
    }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <?php if(session('error')): ?>
    <div class="alert alert-danger alert-dismissible">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <h4><i class="icon fa fa-ban"></i> <?php echo e(session('error')); ?> </h4>
    </div>
    <?php endif; ?>
    <?php if(Session::has('errorMsg')): ?>
    <div class="alert alert-danger alert-dismissible">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <h4><i class="icon fa fa-ban"></i> <?php echo e(Session('errorMsg')); ?> </h4>
        ..<a href="#" id="errorDetails">Details</a>
        <?php echo (Session::has('errorDetails'))?'<p id="ErrorMsgDetails">'.Session('errorDetails').'</p>':''; ?>

    </div>
    <?php endif; ?>
    <?php if(count($errors)>0): ?>
    <div class="alert alert-danger alert-dismissible">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <h4><i class="icon fa fa-ban"></i> Alert!</h4>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>
    <!-- Directory&Header -->
    <section class="content-header">
        <h1>Activities <small>Tour Update</small> </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> C-Panel</a></li>
            <li><a href="#">Update Tour : <?php echo e($Item->name); ?></a></li>
        </ol>
    </section>
    <!-- end Directory&Header -->
    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-xs-12">
                <!-- box -->
                <div class="box">
                    <div class="box-header with-border">
                        <div class="form-group">
                            <button type="submit" class="btn btn-danger btn-block" id="addNew">
                                <i class="fa fa-paw"></i> Update: <?php echo e($Item->name); ?></button>
                        </div>
                    </div>
                    <div id="basicToggle">
                        <form method="post" action="<?php echo e(route('suItems.update',['id'=>$Item->id])); ?>" enctype="multipart/form-data">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <input type="hidden" name="_method" value="PUT">
                            <input type="hidden" value="<?php echo e(Auth::user()->id); ?>" name="supplier_id">
                            <div class="box-body">
                                <div class="row">
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label>Attraction Name:</label>
                                            <select class="form-control" name="attraction_id">
                                                <option value="">Select an Attraction</option>
                                                <?php $__currentLoopData = \App\Models\Attraction::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                                <option value="<?php echo e($category->id); ?>" <?php echo ($category->id==$Item->attraction_id)?'selected="selected"':''; ?>><?php echo e($category->name); ?> ( <?php echo e($category->sort->name); ?>/<?php echo e($category->sort->basicsort->name); ?> )</option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label>Tour Name:</label>
                                            <input class="form-control" value="<?php echo e($Item->name); ?>" name="name"  required>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label>Tour page title:</label>
                                            <input class="form-control" value="<?php echo e($Item->title); ?>" name="title" required>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label>Cancellation policy: in days</label>
                                            <input type="number" class="form-control" name="cancellation" value="<?php echo e($Item->cancellation); ?>" min="0"  required>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-3">
                                        <div class="form-group <?php echo e($errors->has('img')?'has-error':''); ?>">
                                            <label>Image</label>
                                            <input type="file" class="form-control" name="img">
                                            <?php if($errors->has('img')): ?>
                                            <span class="help-block">It has to be an Image File</span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label>Duration:</label>
                                            <input type="number" class="form-control" name="duration" value="<?php echo e($Item->duration); ?>" required>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label>Keywords:</label>
                                            <input class="form-control" value="<?php echo e($Item->keywords); ?>" name="keywords" placeholder="-- Keywords --" >
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label>Description:</label>
                                            <input class="form-control" value="<?php echo e($Item->description); ?>" name="description" placeholder="-- Description --" >
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label>Intro</label>
                                            <textarea class="form-control" name="intro"><?php echo e($Item->intro); ?></textarea>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <button class="btn btn-danger"><i class="fa fa-bicycle"></i> Update <?php echo e($Item->name); ?></button>
                                </div>
                                <div class="form-group"> </div>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Item Price -->
                <div class="box">
                    <div class="box-header with-border">
                        <h3 class="box-title"><a href="#"><i class="fa fa-th"></i> Tour Prices Definitions</a> </h3>
                    </div>
                    <div class="box-body">
                        <?php if(! is_null($price_def)): ?>
                        <div class="row">
                            <div class="col-md-1">
                                <span class="h4">First:</span>
                            </div>
                            <div class="col-md-2">
                                <?php echo e($price_def->st_price_name); ?> 
                                <span style="display:block;">(<?php echo e($price_def->st_price_def); ?>)</span>
                            </div>
                            <div class="col-md-1">
                                <span class="h4">Second:</span>
                            </div>
                            <div class="col-md-2">
                                <?php echo e($price_def->sec_price_name); ?>

                                <span style="display:block;">(<?php echo e($price_def->sec_price_def); ?>)</span>
                            </div>
                            <div class="col-md-1">
                                <span class="h4">Third:</span>
                            </div>
                            <div class="col-md-2">
                                <?php echo e($price_def->third_price_name); ?>

                                <span style="display:block;">(<?php echo e($price_def->third_price_def); ?>)</span>
                            </div>
                            <div class="col-md-3">
                                <button class="btn btn-warning btn-block"><i class="fa fa-pencil-square"></i> Edit</button>
                            </div>
                        </div>
                        <?php else: ?>
                        <div>
                            <form method="post" action="<?php echo e(route('Price_Definitions.store')); ?>">
                                <input type="hidden" value="<?php echo e(csrf_token()); ?>" name="_token">
                                <input type="hidden" value="<?php echo e($Item->id); ?>" name="item_id">
                                <div class="row">
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label>First price name:</label>
                                            <input type="text" name="st_price_name" class="form-control" placeholder="Eg : Adult" required="">
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label>First definition:</label>
                                            <input type="text" name="st_price_def" class="form-control" placeholder="Eg : Age 13-61" required="">
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label>Second price name:</label>
                                            <input type="text" name="sec_price_name" class="form-control" placeholder="Eg : Child" required="">
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label>Second definition:</label>
                                            <input type="text" name="sec_price_def" class="form-control" placeholder="Eg : Age 0-3" required="">
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label>Third price name:</label>
                                            <input type="text" name="third_price_name" class="form-control" placeholder="Eg : Inf">
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label>Third definition:</label>
                                            <input type="text" name="third_price_def" class="form-control" placeholder="Eg : Age <13">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label></label>
                                            <button class="btn btn-primary form-control"><i class="fa fa-paw"></i> Add Price Definition</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <?php endif; ?>


                    </div>
                </div>
                <div class="box">
                    <div class="box-header with-border">
                        <h3 class="box-title"><a href="#"><i class="fa fa-th"></i> Tour Prices</a> Table</h3>
                    </div>
                    <div class="box-body">
                        <div class="row" style="margin-bottom:40px;">
                            <div class="col-md-12">
                                <button class="btn btn-block btn-success" id="add_new_price">
                                    <i class="fa fa-money"></i> Add new Price
                                </button>
                            </div>
                        </div>
                        <form action="<?php echo e(route('Price.store')); ?>" method="post">
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" value="<?php echo e($Item->id); ?>" name="item_id">
                            <div style="display:none;" id="price_form">
                                <div class="row">
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label>First Price</label>
                                            <input type="number" class="form-control" name="st_price"  min="0" required>
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label>Second Price</label>
                                            <input type="number" class="form-control" name="sec_price"  min="0" required>
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label>Third Price</label>
                                            <input type="number" class="form-control" value="" name="third_price" min="0" >
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label>Private</label>
                                            <select name="private" class="form-control">
                                                <option value="0">Not Private</option>
                                                <option value="1">Private</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label>Language</label>
                                            <select class="form-control" name="language">
                                                <option value="">Select Language</option>
                                                <option value="english">English</option>
                                                <option value="spanish">Spanish</option>
                                                <option value="italian">Italian</option>
                                                <option value="russian">Russian</option>
                                                <option value="german">German</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label>Capacity</label>
                                            <input type="number" class="form-control" name="capacity" min="0">
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label>Days</label>
                                            <select class="form-control" name="week_day">
                                                <option value="all">Every Day</option>
                                                <option value="Saturday">Saturday</option>
                                                <option value="Sunday">Sunday</option>
                                                <option value="Monday">Monday</option>
                                                <option value="Tuesday">Tuesday</option>
                                                <option value="Thursday">Thursday</option>
                                                <option value="Wednesday">Wednesday</option>
                                                <option value="Friday">Friday</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="bootstrap-timepicker">
                                            <div class="form-group">
                                                <label>Starting time:</label>
                                                <div class="input-group">
                                                    <input type="text" name="starting_time" class="form-control timepicker" required>
                                                    <div class="input-group-addon"> <i class="fa fa-clock-o"></i> </div>
                                                </div>
                                                <!-- /.input group -->
                                            </div>
                                            <!-- /.form group -->
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label>*</label>
                                            <button class="btn btn-success btn-block"><i class="fa fa-pencil"></i> Add Price</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>

                        <div class="table-responsive">
                            <table class="table-striped" style="min-width: 100%;">
                                <thead>
                                    <tr>
                                        <th>First Price</th>
                                        <th>Second Price</th>
                                        <th>Third Price</th>
                                        <th>Private</th>
                                        <th>Language</th>
                                        <th>Capacity</th>
                                        <th>Days</th>
                                        <th>Starting@</th>
                                        <td>Discount</td>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(!empty ($Item->price)): ?>
                                    <?php $__currentLoopData = $Item->price()->where('deleted',0)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <tr>
                                        <td class="pricetable">
                                            <?php echo e($price->st_price); ?>

                                        </td>
                                        <td class="pricetable">
                                            <?php echo e($price->sec_price); ?>

                                        </td>
                                        <td class="pricetable">
                                            <?php echo e($price->third_price); ?>

                                        </td>
                                        <td class="pricetable">
                                            <?php echo $price->private?'<i class="fa fa-circle text-green"></i>':'<i class="fa fa-circle text-gray"></i> '; ?>

                                        </td>
                                        <td class="pricetable">
                                            <?php echo e($price->language); ?>

                                        </td>
                                        <td class="pricetable">
                                            <?php echo e($price->capacity); ?>

                                        </td>
                                        <td class="pricetable">
                                            <?php echo e($price->week_day); ?>

                                        </td>
                                        <td class="pricetable">
                                            <?php echo e($price->starting_time); ?>

                                        </td>
                                        <td>
                                            <input class="form-control" style="width:100px;" type="number" form="change_discount_<?php echo e($price->id); ?>" value="<?php echo e($price->discount); ?>" min="0" name="discount" required>
                                        </td>
                                        <td class="text-right pricetable" style="min-width: 150px; padding-bottom: 5px; padding-top: 5px;">
                                            <?php
                                            if ($price->status) {
                                                $value = 0;
                                                $word = "disable";
                                                $class = "btn-warning";
                                            } else {
                                                $value = 1;
                                                $word = "enable";
                                                $class = "btn-success";
                                            }
                                            ?>
                                            <button class="btn btn-success btn-sm" form="change_discount_<?php echo e($price->id); ?>">Update</button>
                                            <button class="btn <?php echo e($class); ?> btn-sm" id="do_change"><?php echo e($word); ?></button>
                                            <a class="btn btn-danger btn-sm" id="delet_price"><i class="fa fa-trash"></i></a>
                                            <form method="post" action="<?php echo e(route('Price.update',['id'=>$price->id])); ?>" id="change_status">
                                                <?php echo e(csrf_field()); ?>

                                                <input type="hidden" name="_method" value="PUT">
                                                <input type="hidden" name="status" value="<?php echo e($value); ?>">
                                            </form>
                                            <form method="post" action="<?php echo e(route('Price.update.discount',['id'=>$price->id])); ?>" id="change_discount_<?php echo e($price->id); ?>">
                                                <?php echo e(csrf_field()); ?>

                                                <input type="hidden" name="_method" value="Post">
                                            </form>
                                            <form action="<?php echo e(route('Price.destroy',['id'=>$price->id])); ?>" method="post" id="price_destory">
                                                <?php echo e(csrf_field()); ?>

                                                <input type="hidden" value="DELETE" name="_method">
                                            </form>

                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                    <?php endif; ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <!-- Item Price End -->
                <!-- Item Exploration  -->
                <div class="box">
                    <div class="box-header with-border">
                        <h3 class="box-title"><a href="#"><i class="fa fa-clock-o"></i> Exploration </a></h3>
                    </div>
                    <div class="box-body">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <select class="form-control" name="galleryAction" id="galleryNav">
                                        <option value="">Select an Action</option>
                                        <option value="<?php echo e(route('Exploration.create',['itemID'=>$Item->id])); ?>">Add New</option>
                                        <option value="<?php echo e(route('Exploration.index',['itenID'=>$Item->id])); ?>">Exploration List</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Item Exploration End -->


                <div>
                    <form action="<?php echo e(route('Information.create',['itemID'=>$Item->id])); ?>" method="get">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>Add New Details To This Items</label>
                                    <select name="modelName" class="form-control" id="detailsNavigatore">
                                        <option value="">Select Details to Add</option>
                                        <option value="Highlight">Highlights</option>
                                        <option value="inclusion">Inclusions</option>
                                        <option value="exclusion">Exclusions</option>
                                        <option value="additional">Know before you go</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>

                <div class="row">
                    <div class="col-md-6">
                        <!-- Inclusions -->
                        <div class="box">
                            <div class="box-header">
                                <h3 class="box-title">Inclusions Table</h3>
                            </div>
                            <div class="box-body no-padding">
                                <table class="table table-striped">
                                    <tr>
                                        <th style="width: 10px">#</th>
                                        <th>Inclusions Text</th>
                                        <th>Edit</th>
                                        <th style="width: 40px">Delete</th>
                                    </tr>
                                    <?php $oredr = 1 ?>
                                    <?php $__currentLoopData = $Item->inclusion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inclusion): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <tr>
                                        <td><?php echo e($oredr); ?></td>
                                        <td><?php echo e($inclusion->txt); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('Information.edit',['item'=>$Item->id,'Information'=>$inclusion->id,'modelName'=>'inclusion'])); ?>" class="btn btn-xs btn-warning">
                                                Edit</a>
                                        </td>
                                        <td>
                                            <form action="<?php echo e(route('Information.destroy',[$Item->id,$inclusion->id])); ?>" method="post">
                                                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                                <input type="hidden" name="_method" value="DELETE">
                                                <input type="hidden" name="modelName" value="inclusion">
                                                <a class="deleteItem" href="#" title="<?php echo e($inclusion->id); ?>"><i class="fa fa-trash"></i></a>
                                            </form>
                                        </td>
                                    </tr>
                                    <?php $oredr++ ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                </table>
                            </div>
                        </div>
                        <!-- end Inclusions-->
                        <!-- Additional Information -->
                        <div class="box">
                            <div class="box-header">
                                <h3 class="box-title">Know before you go</h3>
                            </div>
                            <div class="box-body no-padding">
                                <table class="table table-striped">
                                    <tr>
                                        <th style="width: 10px">#</th>
                                        <th>Information Text</th>
                                        <th>Edit</th>
                                        <th style="width: 40px">Delete</th>
                                    </tr>
                                    <?php $oredr = 1 ?>
                                    <?php $__currentLoopData = $Item->additional; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $additional): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <tr>
                                        <td><?php echo e($oredr); ?></td>
                                        <td><?php echo e($additional->txt); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('Information.edit',['item'=>$Item->id,'rowID'=>$additional->id,'modelName'=>'additional'])); ?>" class="btn btn-xs btn-warning">
                                                Edit</a>
                                        </td>
                                        <td>
                                            <form action="<?php echo e(route('Information.destroy',[$Item->id,$additional->id])); ?>" method="post">
                                                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                                <input type="hidden" name="_method" value="DELETE">
                                                <input type="hidden" name="modelName" value="additional">
                                                <a class="deleteItem" href="#" title="<?php echo e($additional->id); ?>"><i class="fa fa-trash"></i></a>
                                            </form>
                                        </td>
                                    </tr>
                                    <?php $oredr++ ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                </table>
                            </div>
                        </div>
                        <!-- end Additional Information-->
                    </div>
                    <div class="col-md-6">
                                                <!-- Highlights -->
                        <div class="box">
                            <div class="box-header">
                                <h3 class="box-title">Highlights Table</h3>
                            </div>
                            <div class="box-body no-padding">
                                <table class="table table-striped">
                                    <tr>
                                        <th style="width: 10px">#</th>
                                        <th>Highlights Text</th>
                                        <th>Edit</th>
                                        <th style="width: 40px">Delete</th>
                                    </tr>
                                    <?php $oredr = 1 ?>
                                    <?php $__currentLoopData = $Item->highlights; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $highlight): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <tr>
                                        <td><?php echo e($oredr); ?></td>
                                        <td><?php echo e($highlight->txt); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('Information.edit',['item'=>$Item->id,'Information'=>$highlight->id,'modelName'=>'exclusion'])); ?>" class="btn btn-xs btn-warning">
                                                Edit</a>
                                        </td>
                                        <td>
                                            <form action="<?php echo e(route('Information.destroy',[$Item->id,$highlight->id])); ?>" method="post">
                                                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                                <input type="hidden" name="_method" value="DELETE">
                                                <input type="hidden" name="modelName" value="exclusion">
                                                <a class="deleteItem" href="#" title="<?php echo e($highlight->id); ?>"><i class="fa fa-trash"></i></a>
                                            </form>
                                        </td>
                                    </tr>
                                    <?php $oredr++ ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                </table>
                            </div>
                        </div>
                        <!-- end Highlights-->
                        <!-- Exclusion -->
                        <div class="box">
                            <div class="box-header">
                                <h3 class="box-title">Exclusions Table</h3>
                            </div>
                            <div class="box-body no-padding">
                                <table class="table table-striped">
                                    <tr>
                                        <th style="width: 10px">#</th>
                                        <th>Exclusions Text</th>
                                        <th>Edit</th>
                                        <th style="width: 40px">Delete</th>
                                    </tr>
                                    <?php $oredr = 1 ?>
                                    <?php $__currentLoopData = $Item->exclusion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exclusion): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <tr>
                                        <td><?php echo e($oredr); ?></td>
                                        <td><?php echo e($exclusion->txt); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('Information.edit',['item'=>$Item->id,'Information'=>$exclusion->id,'modelName'=>'exclusion'])); ?>" class="btn btn-xs btn-warning">
                                                Edit</a>
                                        </td>
                                        <td>
                                            <form action="<?php echo e(route('Information.destroy',[$Item->id,$exclusion->id])); ?>" method="post">
                                                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                                <input type="hidden" name="_method" value="DELETE">
                                                <input type="hidden" name="modelName" value="exclusion">
                                                <a class="deleteItem" href="#" title="<?php echo e($exclusion->id); ?>"><i class="fa fa-trash"></i></a>
                                            </form>
                                        </td>
                                    </tr>
                                    <?php $oredr++ ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                </table>
                            </div>
                        </div>
                        <!-- end Inclusions-->
                        <!-- Item Gallery -->
                        <div class="box">
                            <div class="box-header with-border">
                                <h3 class="box-title"><a href="#"><i class="fa fa-android"></i> Gallery </a></h3>
                            </div>
                            <div class="box-body">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <select class="form-control" name="galleryAction" id="galleryNav">
                                                <option value="">Select an Action</option>
                                                <option value="<?php echo e(route('ItemGallery.create',['itemID'=>$Item->id])); ?>">Upload New Images</option>
                                                <option value="<?php echo e(route('ItemGallery.index',['itenID'=>$Item->id])); ?>">Gallery List</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Item Gallery End -->

                    </div>

                </div>

            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </section>
    <!-- end content -->
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('Extra_Js'); ?>
<script src="<?php echo e(asset('js/admin/admin.js')); ?>"></script>
<script src="<?php echo e(asset('adminlte/plugins/select2/select2.full.min.js')); ?>"></script>
<script src="<?php echo e(asset('adminlte/plugins/timepicker/bootstrap-timepicker.min.js')); ?>"></script>
<script>
$(function () {
    $(".select2").select2();
    $(".timepicker").timepicker({
        showInputs: false,
        showMeridian: false
    });
});
</script>
<script>
    $(document).ready(function () {
        $("#add_new_price").click(function () {
            $("#price_form").show();
        });
        $("button#do_change").click(function () {
            var it_form = $(this).closest("td").find("form#change_status");
            it_form.submit();
        });
        $("a#delet_price").click(function (event) {
            event.preventDefault();
            var it_form = $(this).closest("tr").find("form#price_destory");
            it_form.submit();

        });
    });

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Supplier.Layouts.Layout_Basic', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>