<?php $__env->startSection('meta_tags'); ?>
<title>Write a Review</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header-nav'); ?>
<?php echo $__env->make('Web.nav-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>



<div class="row intital-pages" style="margin-bottom: 30px;">
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <div class="review-write-container">
                    <div class="row review-write-header">
                        <div class="col-md-3">
                            <div class="review-write-img">
                                <img src="<?php echo e(asset('images/items/thumb/'.$item->img)); ?>" alt="<?php echo e($item->title); ?>" class="img-abs-center">
                            </div>
                        </div>
                        <div class="col-md-9">
                            <h2><?php echo e($item->name); ?></h2>
                        </div>
                    </div>
                    <div class="row review-write-help">
                        <div class="col-md-12">
                            <?php echo e(vars::getVar('Your_first-hand_experiences_really_help_other_travelers._Thanks!')); ?>

                        </div>
                    </div>
                    <form action="<?php echo e(route('review.edit')); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="item_id" value="<?php echo e($item->id); ?>">
                        <div class="form-group">
                            <label><?php echo e(Vars::getVar('Your_overall_rating_of_this_attraction')); ?></label>
                            <input type="text" name="overall_rating" class="kv-fa rating-loading" min="1" max="5" value="0" data-size="xs" required>
                        </div>
                         <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label><?php echo e(Vars::getVar('Full_name')); ?></label>
                                    <input class="form-control" name="user_name" placeholder="" required>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label><?php echo e(Vars::getVar('Email')); ?></label>
                                    <input type="email" class="form-control" name="user_email" placeholder="" required>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label><?php echo e(Vars::getVar('Where_are_you_from?')); ?></label>
                                    <input class="form-control" name="user_country" placeholder="" required>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label><?php echo e(Vars::getVar('Title_of_your_review')); ?></label>
                            <input class="form-control" name="title" placeholder="Summarize your visit or highlight an interesting detail" required>
                        </div>
                        <div class="form-group">
                            <label><?php echo e(Vars::getVar('Your_review')); ?></label>
                            <textarea class="form-control" name="review" placeholder="Tell people about your experience: your room, location, amenities?" required></textarea>
                        </div>
                        <div class="form-group">
                            <label><?php echo e(Vars::getVar('When_did_you_travel?')); ?></label>
                            <input class="form-control" name="visit_date" id="visit_date">
                        </div>
                        <div class="form-group">
                            <button class="btn btn-success"><?php echo e(Vars::getVar('Submit_your_review')); ?></button>
                        </div>
                    </form>

                </div>


            </div>
            <div class="col-md-4">
                <?php echo $__env->make('Web.Layouts.rightSide', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>

        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('_extra_css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('kartik-star-rating/css/star-rating.css')); ?>" media="all" type="text/css"/>
<link rel="stylesheet" href="<?php echo e(asset('kartik-star-rating/css/themes/krajee-uni/theme.css')); ?>" media="all" type="text/css"/>
<link rel="stylesheet" href="<?php echo e(asset('css/datepicker/zebra_datepicker.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('_extra_js'); ?>
<script src="<?php echo e(asset('kartik-star-rating/js/star-rating.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('kartik-star-rating/themes/krajee-uni/theme.js')); ?>" type="text/javascript"></script>
<script type="text/javascript" src="<?php echo e(asset('js/datepicker/zebra_datepicker.min.js')); ?>"></script>
<script>
$(document).on('ready', function () {
    $('.kv-fa').rating({
        theme: 'krajee-fa',
        step: 1.0,
        animate: false,
        showClear: false,
        filledStar: '<i class="fa fa-star"></i>',
        emptyStar: '<i class="fa fa-star-o"></i>',
        starCaptions: {
            1: 'Terrible',
            2: 'Poor',
            3: 'Average',
            4: 'Very Good',
            5: 'Excellent'
        }
    });
});
$('#visit_date').Zebra_DatePicker({
    format: 'Y-m-d',
    default_position: 'below'
});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Web.Layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>