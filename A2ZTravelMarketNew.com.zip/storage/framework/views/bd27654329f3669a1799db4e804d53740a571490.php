<?php $__env->startSection('meta_tags'); ?>
<title><?php echo e($topic->title); ?></title>
<meta name="keywords" content="<?php echo e($topic->keywords); ?>">
<meta name="description" content="<?php echo e($topic->description); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header-nav'); ?>
<?php echo $__env->make('Web.nav-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>



<div class="row intital-pages" style="margin-bottom: 30px;">
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <div class="row">
                    <ul class="list-inline directory">
                        <li><a href=""><?php echo e(Vars::getVar("Home")); ?><span class="glyphicon glyphicon-chevron-right" style="font-size: 10px;"></span></a></li>
                        <li><a href=""><?php echo e(Vars::getVar('Articles')); ?> <span class="glyphicon glyphicon-chevron-right"></span></a>
                        <li><a href=""><?php echo e($topic->name); ?></a>
                    </ul>
                    <h1><?php echo e($topic->title); ?></h1>
                </div>
                <?php if($topic->Topics_text): ?>
                <?php echo $topic->Topics_text->txt; ?>

                <?php endif; ?>

            </div>
            <div class="col-md-4">
                <?php echo $__env->make('Web.Layouts.rightSide', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>

        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('_extra_css'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.11.2/moment.min.js"></script>
<link rel="stylesheet" href="<?php echo e(asset('adminlte/plugins/daterangepicker/daterangepicker.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('adminlte/plugins/select2/select2.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('_extra_js'); ?>
<script src="<?php echo e(asset('adminlte/plugins/select2/select2.full.min.js')); ?>"></script>
<!-- date Range -->
<script src="<?php echo e(asset('adminlte/plugins/daterangepicker/daterangepicker.js')); ?>"></script>
<script>
$(function() {
//Initialize Select2 Elements
    $(".select2").select2();
    $('#reservation').daterangepicker({
        startDate: new Date(),
        minDate: new Date()

    });


});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Web.Layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>