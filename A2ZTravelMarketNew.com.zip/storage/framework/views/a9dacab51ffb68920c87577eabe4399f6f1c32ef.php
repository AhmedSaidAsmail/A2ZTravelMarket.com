<?php $__env->startSection('meta_tags'); ?>
<title>Write a Review</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header-nav'); ?>
<?php echo $__env->make('Web.nav-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>



<div class="row intital-pages" style="margin-bottom: 30px;">
    <div class="container">
        <div class="row">
            <div class="col-md-8">

                <div class="row review-write-header">
                    <div class="col-md-3">
                        <div class="review-write-img">
                            <img src="<?php echo e(asset('images/items/thumb/'.$item->img)); ?>" alt="<?php echo e($item->title); ?>" class="img-abs-center">
                        </div>
                    </div>
                    <div class="col-md-9">
                        <h2><?php echo e($item->name); ?></h2>
                    </div>
                </div>
                <div class="row review-write-help">
                    <div class="col-md-12">
                        <?php echo e(vars::getVar('Your_first-hand_experiences_really_help_other_travelers._Thanks!')); ?>

                    </div>
                </div>
               
                    <div class="form-group">
                        <label><?php echo e(Vars::getVar('Your_overall_rating_of_this_attraction')); ?></label>
                        <input type="text" class="kv-fa rating-loading" min="1" max="5" value="0" data-size="xs" title="">
                    </div>
                <div class="form-group">
                    <label>Title of your review</label>
                    <input class="form-control" name="title" placeholder="Summarize your visit or highlight an interesting detail">
                </div>
                <div class="form-group">
                    <label>Your review</label>
                    <textarea class="form-control" name="review" placeholder="Tell people about your experience: your room, location, amenities?"></textarea>
                </div>
                <div class="form-group">
                    <label>When did you travel?</label>
                    <select name="visit_date" class="form-control">
                        
                    </select>
                </div>





            </div>
            <div class="col-md-4">
                <?php echo $__env->make('Web.Layouts.rightSide', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>

        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('_extra_css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('kartik-star-rating/css/star-rating.css')); ?>" media="all" type="text/css"/>
<link rel="stylesheet" href="<?php echo e(asset('kartik-star-rating/css/themes/krajee-uni/theme.css')); ?>" media="all" type="text/css"/>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('_extra_js'); ?>
<script src="<?php echo e(asset('kartik-star-rating/js/star-rating.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('kartik-star-rating/themes/krajee-uni/theme.js')); ?>" type="text/javascript"></script>
<script>
$(document).on('ready', function () {
    $('.kv-fa').rating({
        theme: 'krajee-fa',
        step: 1.0,
        animate: false,
        showClear: false,
        filledStar: '<i class="fa fa-star"></i>',
        emptyStar: '<i class="fa fa-star-o"></i>',
        starCaptions: {
            1: 'Terrible',
            2: 'Poor',
            3: 'Average',
            4: 'Very Good',
            5: 'Excellent'
        }
    });
});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Web.Layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>