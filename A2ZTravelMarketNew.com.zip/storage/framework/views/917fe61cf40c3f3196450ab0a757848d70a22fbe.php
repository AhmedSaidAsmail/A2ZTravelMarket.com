<?php $__env->startSection('meta_tags'); ?>
<title>My Wishlist</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<h1 class="wishlist-header">My Wishlist</h1>
<span class="wishlist-span"><i class="fa fa-heart-o"></i> 
    <?php if(Auth::guard('customer')->check()): ?>
    <?php echo e(\App\Http\Controllers\Web\WishlistController::customerWishlistCount()); ?> 
    <?php else: ?>
    <?php if(Session::has('wishlist') && Session::get('wishlist')->totalQty >0): ?>
    <?php echo e(Session::get('wishlist')->totalQty); ?>

    <?php endif; ?>
    <?php endif; ?>
    item</span>
<?php
if (Auth::guard('customer')->check()) {
    $cutomer_id = Auth::guard('customer')->user()->id;
} else {
    $cutomer_id = null;
}
?>
<?php if(!is_null($customerWishlist)): ?>
<?php $__currentLoopData = $customerWishlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wishlist): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
<?php
$item = $wishlist->item;
?>
<a href="<?php echo e(route('tour.show',['city'=>$item->attraction->sort->name,'tour'=>$item->name,'id'=>$item->id])); ?>" class="item-tour-link">
    <div class="row item-tour" id="item-tour">
        <a href="<?php echo e(route('wishlist.remove')); ?>?item_id=<?php echo e($item->id); ?>&customer_id=<?php echo e($cutomer_id); ?>" class="remove-wishlist"><i class="fa fa-times"></i></a>
        <div class="col-md-3">
            <div class="item-tour-img">
                <img src="<?php echo e(asset('images/items/thumb/'.$item->img)); ?>" class="img-abs-center" alt="<?php echo e($item->name); ?>">
            </div>
        </div>
        <div class="col-md-9 item-tour-right">
            <div class="tour-price-from"><span><?php echo e(Vars::getVar('From')); ?></span><?php echo e(Vars::getVar('€')); ?>

                <?php echo e(\App\Http\Controllers\Web\AttractionController::getLowestPrice($item->id)); ?></div>
            <div class="tour-duration">
                <i class="fa fa-clock-o"></i> <label><?php echo e(Vars::getVar('Duration')); ?>:</label> <?php echo e($item->duration); ?> <?php echo e(Vars::getVar('hours')); ?>

            </div>
            <h2><?php echo e($item->name); ?><?php echo e($item->id); ?></h2>
            <div class="item-tour-rating">
                <?php echo e(App\Http\Controllers\ReviewController::getRateStar(App\Http\Controllers\ReviewsRateCalculate::calc($item->id,'overall_rating'))); ?>

                <?php echo e(count($item->reviews()->where('confirm',1)->get())); ?> <?php echo e(Vars::getVar('Reviews')); ?>

            </div>
            <span class="item-tour-intro">
                <?php echo \Illuminate\Support\Str::limit($item->intro, $limit = 147, $end = '...'); ?>

            </span>
        </div>
    </div>
</a>
<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
<?php else: ?>
<?php if(!is_null($sessionWishlist)): ?>
<?php $__currentLoopData = $sessionWishlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
<?php $item = \App\Models\Item::find($id) ?>
<a href="<?php echo e(route('tour.show',['city'=>$item->attraction->sort->name,'tour'=>$item->name,'id'=>$item->id])); ?>" class="item-tour-link">
    <div class="row item-tour" id="item-tour">
        <a href="<?php echo e(route('wishlist.remove')); ?>?item_id=<?php echo e($item->id); ?>&customer_id=<?php echo e($cutomer_id); ?>" class="remove-wishlist"><i class="fa fa-times"></i></a>
        <div class="col-md-3">
            <div class="item-tour-img">
                <img src="<?php echo e(asset('images/items/thumb/'.$item->img)); ?>" class="img-abs-center" alt="<?php echo e($item->name); ?>">
            </div>
        </div>
        <div class="col-md-9 item-tour-right">
            <div class="tour-price-from"><span><?php echo e(Vars::getVar('From')); ?></span><?php echo e(Vars::getVar('€')); ?>

                <?php echo e(\App\Http\Controllers\Web\AttractionController::getLowestPrice($item->id)); ?></div>
            <div class="tour-duration">
                <i class="fa fa-clock-o"></i> <label><?php echo e(Vars::getVar('Duration')); ?>:</label> <?php echo e($item->duration); ?> <?php echo e(Vars::getVar('hours')); ?>

            </div>
            <h2><?php echo e($item->name); ?><?php echo e($item->id); ?></h2>
            <div class="item-tour-rating">
                <?php echo e(App\Http\Controllers\ReviewController::getRateStar(App\Http\Controllers\ReviewsRateCalculate::calc($item->id,'overall_rating'))); ?>

                <?php echo e(count($item->reviews()->where('confirm',1)->get())); ?> <?php echo e(Vars::getVar('Reviews')); ?>

            </div>
            <span class="item-tour-intro">
                <?php echo \Illuminate\Support\Str::limit($item->intro, $limit = 147, $end = '...'); ?>

            </span>
        </div>
    </div>
</a>
<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
<?php endif; ?>
<?php endif; ?>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('Web.Layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>