<!doctype html>
<html lang="en">
    <head>

        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <?php echo $__env->yieldContent('meta_tags'); ?>
        <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/animate.min.css')); ?>">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
        <?php echo $__env->yieldContent('_extra_css'); ?>
    </head>
    <body id="exc">
        <?php echo $__env->yieldContent('extra-plugged-in'); ?>
        <!-- header -->
        <div class="row">
            <div class="container">
                <nav class="navbar" id="header-nav">
                    <div class="container-fluid headerLinks">
                        <ul class="nav navbar-nav navbar-right">
                            <li><a href="<?php echo e(route('home')); ?>"><span class="glyphicon glyphicon-home"></span><?php echo e(Vars::getVar("Home")); ?></a></li>
                            <li><a href="<?php echo e(route('cart')); ?>"><span class="glyphicon glyphicon-shopping-cart"></span>Cart <span class="badge" id="shoping-cart-header">
                                        <?php echo e(Session::has('cart')?Session::get('cart')->totalQty:0); ?>

                                    </span></a></li>
                            <?php $__currentLoopData = App\MyModels\Admin\Topic::where('top',1)->orderBy('arrangement','desc')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $top): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <li><a href="<?php echo e(route('topics.show',['topicsName'=>urlencode($top->name)])); ?>"><?php echo e($top->top_link); ?> </a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            <li><a href="">Sharm  excursions</a></li>
                            <li><a href="" ><span class="glyphicon glyphicon-question-sign"></span><?php echo e(Vars::getVar("Help")); ?></a></li>
                        </ul>
                    </div>
                </nav>
            </div>
        </div>
        <!-- Navigation Menu -->
        <div class="row main-nav-normal animated" id="main-nav">

            <div class="container" id="responsive-nav">
                <div class="col-sm-2 col-xs-2 mob-menu">
                    <div id="responsive-menu">
                        <i class="fa fa-bars" aria-hidden="true"></i>
                        MENU
                    </div>
                </div>
                <div class="col-md-3 logo-conatiner col-sm-8 col-xs-8">
                    <span class="logo-header logo-header-position"></span> <p>SharmTour.com Travel's budget!</p></div>
                <div class="col-sm-2 col-xs-2 mob-cart">
                    <a href=""><span class="glyphicon glyphicon-shopping-cart"></span> <span class="badge">0</span></a>
                </div>

                <ul class="nav navbar-nav" id="main-nav-main">
                    <?php
                    $itemClass = null;
                    ?>
                    <?php $__currentLoopData = $Categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <?php
                    if (!isset($activeLink) && is_null($itemClass)) {
                        $itemClass = "active-link";
                    } elseif (isset($activeLink) && $activeLink == $category->id) {
                        $itemClass = "active-link";
                    } else {
                        $itemClass = "normal-link";
                    }
                    ?>
                    <li><a href="<?php echo e(route('cities.show',['city'=>urlencode($category->name),'id'=>$category->id])); ?>" class="<?php echo e($itemClass); ?>"><i class="fa <?php echo e($category->icon); ?>"></i> <?php echo e($category->name); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                </ul>
                <ul class="nav navbar-nav navbar-right" id="main-nav-right">
                    <li><a href="#"><img src="<?php echo e(asset('images/english-flag.png')); ?>" alt="">UK<span class="caret"></span></a></li>
                </ul>
            </div>
        </div>
        <!-- content -->
        <?php echo $__env->yieldContent('content'); ?>


        <!-- footer -->
        <div class="row footer">
            <div class="container" style="position: relative;">
                <div class="footer-show-toggle"><i class="fa fa-arrow-circle-down"></i> Show less</div>
                <div class="row">

                    <?php $__currentLoopData = App\MyModels\Admin\Topic::where('footer',1)->orderBy('arrangement','desc')->limit(9)->get()->chunk(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $footerChunk): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <div class="col-md-3 col-sm-6 col-xs-6">
                        <ul>
                            <?php $__currentLoopData = $footerChunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $footer): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <li><a href="<?php echo e(route('topics.show',['topicsName'=>urlencode($footer->name)])); ?>"><?php echo e($footer->footer_link); ?> </a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                        </ul>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>



                    <div class="col-md-3">
                        <div class="row">
                            <span class="glyphicon glyphicon-envelope" style="margin-right: 10px; font-size: 20px;"></span>Newsletter: Get the best travel deals delivered to your inbox!
                        </div>
                        <div class="row">
                            <form>
                                <div class="col-md-10 col-sm-10 col-xs-10" style="padding-left: 0px; padding-right: 0px;">
                                    <input type="text" value="" class="form-control" placeholder="Your mail">
                                </div>
                                <div class="col-md-2 col-sm-2 col-xs-2" style="padding-left: 5px;">
                                    <button class="btn btn-success" style="padding: 5px;"><i class="fa fa-check" style="font-size: 20px;"></i></button>
                                </div>
                            </form>
                        </div>
                        <div class="row footer-social-links">
                            <div class="col-md-12 col-sm-8 col-xs-8">
                                <a href="#"> <i class="fa fa-facebook"></i></a>
                                <a href="#"> <i class="fa fa-twitter"></i></a>
                                <a href="#"> <i class="fa fa-google-plus"></i></a>
                                <a href="#"> <i class="fa fa-pinterest-p"></i></a>
                                <a href="#"> <i class="fa fa-feed"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <div class="row" style="background-color: #000; color: #FFF;">

            <div class="container footer-final-links">
                <div class="row">
                    <div class="col-md-4">
                        <h1 class="refrence-title">Top 10 Countries</h1>
                        <ul class="refrence-list">
                            <li><a href="">Rome</a></li>
                            <li><a href="">Paris</a></li>
                            <li><a href="">London</a></li>
                            <li><a href="">Cairo</a></li>
                            <li><a href="">Sharm El Sheikh</a></li>
                            <li><a href="">New York</a></li>
                        </ul>
                    </div>
                    <div class="col-md-4">
                        <h1 class="refrence-title">Top Destinations</h1>
                        <ul class="refrence-list">
                            <li><a href="">Egypt</a></li>
                            <li><a href="">England</a></li>
                            <li><a href="">Jordan</a></li>
                            <li><a href="">Malaysia</a></li>
                            <li><a href="">United States</a></li>
                            <li><a href="">New York</a></li>
                        </ul>
                    </div>
                    <div class="col-md-4">
                        <h1 class="refrence-title">Must-See Attractions</h1>
                        <ul class="refrence-list">
                            <li><a href="">Egypt</a></li>
                            <li><a href="">England</a></li>
                            <li><a href="">Jordan</a></li>
                            <li><a href="">Malaysia</a></li>
                            <li><a href="">United States</a></li>
                            <li><a href="">New York</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="row text-center" style="background-color: #f2f2f2; padding: 10px;">© 2017 sharm-tour.com All Rights Reserved</div>

        <script src="<?php echo e(asset('js/jquery-2.2.3.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/per.min.js')); ?>"></script>
        <?php echo $__env->yieldContent('_extra_js'); ?>
    </body>
</html>
