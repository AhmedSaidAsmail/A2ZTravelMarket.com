<?php $__env->startSection('title','Main Category Panel'); ?>
<?php $__env->startSection('Extra_Css'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/admin/style.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <!-- Directory&Header -->
    <section class="content-header">
        <h1> Review <small>Summery</small> </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> C-Panel </a></li>
            <li><a href="#">Review : <?php echo e($review->id); ?></a></li>
        </ol>
    </section>
    <!-- end Directory&Header -->
    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-md-9">
                <div class="row reviews-summary-container">
                    <div class="row reviews-summary">
                        <div class="col-md-4">
                            <span class="reviews-summary-title">Overall rating</span>
                            <div class="overall-rating">
                                <?php echo e(\App\Http\Controllers\ReviewController::getRateStar($review->overall_rating)); ?>

                                <?php echo e($review->overall_rating); ?> / 5
                            </div>
                        </div>
                        <div class="col-md-8 reviews-summary-all">
                            <span class="reviews-summary-title">Review summary</span>
                            <div class="row">
                                <div class="col-md-3">
                                    Service
                                </div>
                                <div class="col-md-4">
                                    <div class="progress">
                                        <div class="progress-bar" role="progressbar" aria-valuenow="70"
                                             aria-valuemin="0" aria-valuemax="100" style="width:<?php echo e($review->service_rating/5*100); ?>%">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <?php echo e($review->service_rating); ?>/5
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3">
                                    Organization
                                </div>
                                <div class="col-md-4">
                                    <div class="progress">
                                        <div class="progress-bar" role="progressbar" aria-valuenow="70"
                                             aria-valuemin="0" aria-valuemax="100" style="width:<?php echo e($review->organization_rating/5*100); ?>%">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <?php echo e($review->organization_rating); ?>/5
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3">
                                    Value for money
                                </div>
                                <div class="col-md-4">
                                    <div class="progress">
                                        <div class="progress-bar" role="progressbar" aria-valuenow="70"
                                             aria-valuemin="0" aria-valuemax="100" style="width:<?php echo e($review->value_rating/5*100); ?>%">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <?php echo e($review->value_rating); ?>/5
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3">
                                    Safety
                                </div>
                                <div class="col-md-4">
                                    <div class="progress">
                                        <div class="progress-bar" role="progressbar" aria-valuenow="70"
                                             aria-valuemin="0" aria-valuemax="100" style="width:<?php echo e($review->safety_rating/5*100); ?>%">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <?php echo e($review->safety_rating); ?>/5
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>

        <div class="row" style="margin: 10px 0px;">
            <div class="col-md-9" style="background-color: #FFF;">
                <div class="review-show">

                    <div class="row">
                        <div class="col-md-9">
                            <h2>"<?php echo e($review->title); ?>"</h2>
                            <div class="review-show-rate">
                                <?php echo e(App\Http\Controllers\ReviewController::getRateStar($review->overall_rating)); ?>


                            </div>
                            <div class="review-show-msg">
                                <?php echo e($review->review); ?>

                            </div>
                            <div class="review-show-owner">
                                reviewed by <span><?php echo e($review->customer->name); ?> – <?php echo e($review->customer->country); ?></span>
                            </div>
                        </div>
                        <span class="review-show-date"><?php echo e(date('F d, Y',strtotime($review->visit_date))); ?></span>
                    </div>
                </div>
            </div>
        </div>
        <div class="row" style="margin: 0px;">
            <div class="col-md-1">
                <form action="<?php echo e(route('reviews.destroy',['id'=>$review->id])); ?>" method="post">
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                    <input type="hidden" name="_method" value="DELETE">
                    <button class="btn btn-danger btn-block">Delete</button>
                </form>
            </div>
            <?php if(!$review->confirm): ?>
            <div class="col-md-1">
                <form method="post" action="<?php echo e(route('reviews.update',['id'=>$review->id])); ?>">
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                    <input type="hidden" name="_method" value="PUT">
                    <button class="btn btn-success">Confirm</button>
                </form> 
            </div>
            <?php endif; ?>
        </div>
        <!-- /.row -->
    </section>
    <!-- end content -->
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('Extra_Js'); ?>
<script src="<?php echo e(asset('js/admin/admin.js')); ?>"></script>
<script src="<?php echo e(asset('adminlte/plugins/datatables/dataTables.bootstrap.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.Layouts.Layout_Basic', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>