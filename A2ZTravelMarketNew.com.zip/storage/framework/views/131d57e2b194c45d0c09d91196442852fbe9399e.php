<?php $__env->startSection('meta_tags'); ?>
<title>Your Cart</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<h1 class="cart-header">Hooray, you’ve successfully added 1 item to your cart.</h1>
<h2 class="cart-header">Only 2 more steps to go!</h2>
<span class="cart-warn"><i class="fa fa-clock-o"></i> Once you add an activity to your cart, we will save your spot for 60 minutes.</span>

<div class="row" style="margin-top: 15px;">
    <div class="col-md-8">
        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        <div class="cart-item">
            <div class="row cart-item-det">
                <div class="cart-item-remove">
                    <a href="<?php echo e(route('reservation.cart.remove',['id'=>$key])); ?>"><i class="fa fa-times"></i></a>
                </div>
                <div class="cart-item-price">
                    <?php echo e(Vars::getVar('€').$item['price']); ?>

                </div>
                <div class="col-md-2">
                    <div class="item-card-img">
                        <img src="<?php echo e(asset('images/items/thumb/'.App\Models\Item::find($item['item'])->img)); ?>" class="img-abs-center" alt="">
                    </div>
                </div>
                <div class="col-md-10">
                    <h2><?php echo e(App\Models\Item::find($item['item'])->name); ?></h2>
                    <span>
                        <?php if(!is_null(\App\Models\Price::find($item['price_id'])->language)): ?>
                        <?php echo e(ucfirst(\App\Models\Price::find($item['price_id'])->language)); ?> Tour
                        <?php endif; ?>
                        <?php if(!is_null(\App\Models\Price::find($item['price_id'])->private)): ?>
                        ,Private
                        <?php endif; ?>
                    </span>
                    <span><?php echo e(date('F d,Y',strtotime($item['date']))); ?> 
                        <?php echo e(date('h:i A',strtotime(\App\Models\Price::find($item['price_id'])->starting_time))); ?></span>
                    <span>
                        <?php echo e($item['st_no']); ?> <?php echo e(App\Models\Item::find($item['item'])->price_definition->st_price_name); ?>

                        <?php if($item['sec_no']>0): ?>
                        ,<?php echo e($item['sec_no']); ?> <?php echo e(App\Models\Item::find($item['item'])->price_definition->sec_price_name); ?>

                        <?php endif; ?>
                        <?php if($item['third_no']>0): ?>
                        ,<?php echo e($item['third_no']); ?> <?php echo e(App\Models\Item::find($item['item'])->price_definition->third_price_name); ?>

                        <?php endif; ?>

                    </span>
                </div>
            </div>
            <div class="cart-item-buttom row">
                <div class="col-md-12">
                    Book without regrets! <label>Cancel your activity for free any time up until 
                        <?php echo e(date('F d,Y',strtotime($item['date']." +".App\Models\Item::find($item['item'])->cancellation." day"))); ?>  
                        <?php echo e(date('h:i A',strtotime(\App\Models\Price::find($item['price_id'])->starting_time))); ?></label>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

    </div>

    <div class="col-md-4">
        <div class="cart-all-total">
            <span class="cart-header-total">Total (<?php echo e($qty); ?> items):<label><?php echo e(Vars::getVar('€').$total); ?></label></span>
            <span>No additional fees.</span>
            <a class="btn btn-info btn-block">Checkout</a>
            <div class="cart-all-bottom">
                <a href="">Create an account</a> or <a href="">log in</a>
                <span>for faster checkout.</span>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Web.Layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>