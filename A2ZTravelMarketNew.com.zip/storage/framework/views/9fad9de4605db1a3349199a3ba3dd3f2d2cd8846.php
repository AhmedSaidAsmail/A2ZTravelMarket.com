<?php $__env->startSection('meta_tags'); ?>
<?php $meta = App\MyModels\Admin\Topic::where('name', 'Home')->first() ?>
<meta name="keywords" content="<?php echo e($meta->keywords); ?>" />
<meta name="description" content="<?php echo e($meta->description); ?>" />
<title><?php echo e($meta->title); ?></title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row exc-container">
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <div class="row" style="margin-top: 20px;">
                    <div class="col-md-4 col-xs-4 checkout-refrences checkout-refrences-inactive">
                        <?php echo e(Vars::getVar("Add_to_Cart")); ?>

                        <div class="checkout-refrences-arrow"></div>
                        <div class="checkout-refrences-arrow-bg"></div>
                    </div>
                    <div class="col-md-4 col-xs-4 checkout-refrences checkout-refrences-inactive">
                        <?php echo e(Vars::getVar("Review_Orders")); ?>

                        <div class="checkout-refrences-arrow"></div>
                        <div class="checkout-refrences-arrow-bg"></div>
                    </div>
                    <div class="col-md-4 col-xs-4 checkout-refrences checkout-refrences-active">
                        <?php echo e(Vars::getVar("Secure_checkout")); ?>

                    </div>
                </div>

                <?php if(isset($success)&& $success=='approval' ): ?>
                <div class="row" style="margin-top: 20px;">
                    <h1>THANKS FOR BOOKING WITH US</h1>
                    <h3 style="color:#fe6500; margin-top: 15px; font-size: 18px; "><i class="fa fa-check"></i> We have received your email and our Customer Service team will be responding to you soon</h3>
                </div>
                <?php else: ?>
                <div class="row" style="margin-top: 20px;">

                    <h3 style="color:#fe6500; margin-top: 15px; font-size: 18px; "><i class="fa fa-close"></i> oops something went wrong</h3>
                </div>
                <?php endif; ?>
            </div>

            <div class="col-md-4">
                <div class="row transfer-form">
                    <div class="col-md-12 text-center transfer-form-header">
                        <h3 class="text-center" style="width: 50%; margin: 0 auto;">
                            <i class="fa fa-car" aria-hidden="true"></i> <?php echo e(Vars::getVar("SHARM_TRANSFER")); ?></h3>
                        <?php echo e(Vars::getVar("easy_booking")); ?>


                    </div>
                    <form action="<?php echo e(route('add.transfer.to.cart')); ?>" method="post">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"/>
                        <div class="transfer-form-body">
                            <div class="row" style="padding-top: 75px;">
                                <div class="col-md-6">

                                    <div class="form-group">
                                        <label><?php echo e(vars::getVar("Arrival_Date")); ?></label>

                                        <div class="input-group">
                                            <div class="input-group-addon">
                                                <i class="fa fa-calendar"></i>
                                            </div>
                                            <input name="arrival_date" type="text" class="form-control" data-inputmask="'alias': 'dd/mm/yyyy'" data-mask>
                                        </div>
                                        <!-- /.input group -->
                                    </div>



                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label><?php echo e(vars::getVar("Departure_Date")); ?></label>

                                        <div class="input-group">
                                            <div class="input-group-addon">
                                                <i class="fa fa-calendar"></i>
                                            </div>
                                            <input name="departure_date" type="text" class="form-control" data-inputmask="'alias': 'dd/mm/yyyy'" data-mask>
                                        </div>
                                        <!-- /.input group -->
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6" style="position:relative;">
                                    <div class="loading-small"></div>
                                    <div class="form-group">
                                        <label><?php echo e(vars::getVar("From")); ?></label>
                                        <select name="dist_from" class="form-control select2" style="width: 100%;" id="dist_from" link="<?php echo e(route('searchDist')); ?>" required>
                                            <option selected="selected" value="" >Select Destination</option>
                                            <?php $__currentLoopData = $dist_from; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transfer): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                            <option value="<?php echo e($transfer->dist_from); ?>"><?php echo e($transfer->dist_from); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                        </select>
                                    </div>

                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label><?php echo e(vars::getVar("To")); ?></label>
                                        <select name="dist_to" class="form-control select2" style="width: 100%;" id="dist_to">
                                            <option selected="selected" value="">Select Destinations</option>

                                        </select>
                                    </div>

                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label><?php echo e(vars::getVar("Transfer_Type")); ?></label>
                                        <select name="transfer_type" class="form-control" style="width: 100%; border: 1px solid #fe6500;" required>
                                            <option selected="selected" vlaue=""><?php echo e(vars::getVar("Select_Transfer_Type")); ?></option>
                                            <option value="type_limousine"><?php echo e(vars::getVar("Limousine")); ?></option>
                                            <option value="type_van"><?php echo e(vars::getVar("Van")); ?></option>
                                            <option value="type_coaster"><?php echo e(vars::getVar("Coaster")); ?></option>
                                            <option value="type_bus"><?php echo e(vars::getVar("Bus")); ?></option>

                                        </select>
                                    </div>

                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label><?php echo e(vars::getVar("One-Way/Return")); ?></label>
                                        <select name="transfer_times" class="form-control" style="width: 100%; border: 1px solid #fe6500;">

                                            <option value="1"><?php echo e(vars::getVar("One_Way")); ?></option>
                                            <option value="2"><?php echo e(vars::getVar("Go/Return")); ?></option>
                                        </select>
                                    </div>

                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-12 transfer-text-label">
                                    <i class="fa fa-info-circle" aria-hidden="true"></i> <?php echo e(vars::getVar('Please_select_the_number_of_Adults_and_Children_for_transfer')); ?>

                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label><?php echo e(vars::getVar("Adult")); ?></label>
                                        <input name="adult" type="number" value=""  class="form-control">
                                    </div>

                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label><?php echo e(vars::getVar("Child")); ?></label>
                                        <input name="child" type="number" value=""  class="form-control">
                                    </div>

                                </div>
                            </div>
                            <div class="row text-center">
                                <button class="btn btn-lg" style="margin-bottom: -25px; background-color: #fe6500; color: #FFF;">
                                    <span class="glyphicon glyphicon-shopping-cart"></span> add to Basket <span class="glyphicon glyphicon-arrow-right"></span>
                                </button>
                            </div>
                        </div>
                    </form>
                </div>


                <div class="row">
                    <div class="col-md-12 youtube-holder">
                        <iframe id="youtube"  height="315" src="https://www.youtube.com/embed/jnfwoGw3fnU" frameborder="0" allowfullscreen></iframe>
                    </div>


                </div>



            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-1"></div>
        <div class="col-md-10">
            <div class="row more-attractions">
                <h3><?php echo e(Vars::getVar("More_Things_to_Do_in_Sharm_el_Sheikh")); ?></h3>
                <ul class="list-inline">
                    <?php $__currentLoopData = $Categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Seccategory): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <li><span><a href="<?php echo e(route('cities.show',['city'=>urlencode($Seccategory->name),'id'=>$Seccategory->id])); ?>"><?php echo e($Seccategory->title); ?></a></span></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </ul>
            </div>
            <div class="row more-attractions">
                <h3><?php echo e(Vars::getVar("Top_Sharm_el_Sheikh_Attractions")); ?></h3>
                <ul class="list-inline">
                    <?php $__currentLoopData = $Categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $LinkCategory): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <?php $__currentLoopData = $LinkCategory->items->where('recommended',"=",1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $LinkItems): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>

                    <li><span><a href="<?php echo e(route('tour.show',['city'=>urlencode($LinkCategory->name),'tour'=>urlencode($LinkItems->name),'id'=>$LinkItems->id])); ?>"><?php echo e($LinkItems->title); ?></a></span></li>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </ul>
            </div>
        </div>


    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('_extra_css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('adminlte/plugins/datepicker/datepicker3.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('adminlte/plugins/select2/select2.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('adminlte/plugins/daterangepicker/daterangepicker.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('_extra_js'); ?>
<script src="<?php echo e(asset('adminlte/plugins/select2/select2.full.min.js')); ?>"></script>
<!-- Input Mask -->
<script src="<?php echo e(asset('adminlte/plugins/input-mask/jquery.inputmask.js')); ?>"></script>
<script src="<?php echo e(asset('adminlte/plugins/input-mask/jquery.inputmask.date.extensions.js')); ?>"></script>
<script src="<?php echo e(asset('adminlte/plugins/input-mask/jquery.inputmask.extensions.js')); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.11.2/moment.min.js"></script>
<script src="<?php echo e(asset('adminlte/plugins/daterangepicker/daterangepicker.js')); ?>"></script>
<script>
$(function() {
//Initialize Select2 Elements
    $(".select2").select2();

//Datemask dd/mm/yyyy
    $("#datemask").inputmask("dd/mm/yyyy", {"placeholder": "dd/mm/yyyy"});
//Datemask2 mm/dd/yyyy
    $("#datemask2").inputmask("mm/dd/yyyy", {"placeholder": "mm/dd/yyyy"});
//Money Euro
    $("[data-mask]").inputmask();
    // data range
    $('#reservationtime').daterangepicker({timePicker: true, timePickerIncrement: 30, format: 'DD/MM/YYYY h:mm A'});

});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Web.Layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>