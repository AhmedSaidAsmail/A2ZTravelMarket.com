<?php $__env->startSection('meta_tags'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('header-nav'); ?>
<div class="row">
    <div class="img-top-title">
        <img src="<?php echo e(asset('images/attraction/'.$attraction->img)); ?>" class="img-abs-center" alt="<?php echo e($attraction->name); ?>">
        <h1 class="top-title"><?php echo e(ucfirst($attraction->name)); ?></h1>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-8">
        <h1 class="normal-header"><?php echo e(ucfirst($attraction->name)); ?>: Tours & Tickets</h1>
        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        <a href="<?php echo e(route('tour.show',['city'=>$attraction->sort->name,'tour'=>$item->name,'id'=>$item->id])); ?>" class="item-tour-link">
            <div class="row item-tour">
                <div class="col-md-4">
                    <div class="item-tour-img">
                        <img src="<?php echo e(asset('images/items/thumb/'.$item->img)); ?>" class="img-abs-center" alt="<?php echo e($item->name); ?>">
                    </div>
                </div>
                <div class="col-md-8 item-tour-right">
                    <div class="tour-price-from"><span><?php echo e(Vars::getVar('From')); ?></span>
                        <?php echo \App\Http\Controllers\Web\ItemsController::getLowestPrice2($item->id); ?></div>
                    <div class="tour-duration">
                        <i class="fa fa-clock-o"></i> <label><?php echo e(Vars::getVar('Duration')); ?>:</label> <?php echo e($item->duration); ?> <?php echo e(Vars::getVar('hours')); ?>

                    </div>
                    <h2><?php echo e($item->name); ?></h2>
                    <div class="item-tour-rating">
                        <?php echo e(App\Http\Controllers\ReviewController::getRateStar(App\Http\Controllers\ReviewsRateCalculate::calc($item->id,'overall_rating'))); ?>

                        <?php echo e(count($item->reviews()->where('confirm',1)->get())); ?> <?php echo e(Vars::getVar('Reviews')); ?>

                    </div>
                    <span class="item-tour-intro">
                        <?php echo \Illuminate\Support\Str::limit($item->intro, $limit = 147, $end = '...'); ?>

                    </span>
                </div>
            </div> 
        </a>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        <?php if($moreAttraction): ?>
        <div class="row text-center see-all">
            <a class="btn btn-info" href="<?php echo e(route('attraction.show.all',['id'=>$attraction->id])); ?>">
                See all tours & things to do in <?php echo e($attraction->sort->name); ?> <?php echo e($attraction->name); ?></a>
        </div>
        <?php endif; ?>
    </div>
    <div class="col-md-4">
        <h1 class="normal-header">Top sights in <?php echo e($attraction->sort->name); ?></h1>
        <?php $__currentLoopData = $topCityAttractions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topCityAttraction): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        <div class="img-right-side">
            <a href="<?php echo e(route('attraction.show',['id'=>$topCityAttraction->id])); ?>">
                <img src="<?php echo e(asset('images/attraction/'.$topCityAttraction->img)); ?>" class="img-abs-center" alt="<?php echo e($topCityAttraction->name); ?>">
                <span><?php echo e($topCityAttraction->name); ?></span>
                <p><?php echo e(count($topCityAttraction->items)); ?> activities</p>
            </a>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
    </div>
</div>

<div class="row attraction-city-show">
    <div class="col-md-12">
        <div class="attraction-city-img">
            <img class="img-panorama" src="<?php echo e(asset('images/sorts/'.$attraction->sort->img)); ?>" alt="<?php echo e($attraction->sort->name); ?>">
            <div class="img-panorama-text-cenetr">
                <span><?php echo e(ucfirst($attraction->sort->name)); ?></span>
                <button class="btn btn-info">See all <?php echo e(count($attraction->sort->items)); ?> tours & tickets</button>
            </div>
        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Web.Layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>