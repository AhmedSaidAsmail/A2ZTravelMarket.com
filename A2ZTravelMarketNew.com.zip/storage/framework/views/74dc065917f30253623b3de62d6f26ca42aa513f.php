<?php $oder = 0 ?>
<?php $__currentLoopData = $dates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
<?php if(\App\Http\Controllers\Web\ItemsController::checkAvailability($date,$day)): ?>
<?php
$class = ($oder == 0) ? "price-active" : "price-not-active";
?>
<div class="row price-plane-avaiable <?php echo e($class); ?>">
    <?php if($date->discount > 0): ?>
    <div class="item-tour-discount">
        SAVE UP TO <?php echo e($date->discount); ?>%
    </div>
    <?php endif; ?>
    <div class="col-md-12 first-row">
        <div class="row">
            <div class="col-md-6">
                <?php echo (!is_null($date->language))?ucfirst($date->language)." Tour":null; ?>

                <?php echo (!is_null($date->capacity))?": Up to".$date->capacity." People":null; ?>

            </div>
            <div class="col-md-5 text-right price-plane-total">
                <label>Total price</label>
               <?php echo \App\Http\Controllers\Web\ItemsController::getTotalPrice($request,$date); ?>

            </div>
            <div class="col-md-1 text-right">
                <span class="fa-stack" id="hide-plane">
                    <i class="fa fa-circle fa-stack-2x"></i>
                    <i class="fa fa-check fa-inverse fa-stack-1x"></i>
                </span>
                <span class="fa-stack" id="active-plane">
                    <i class="fa fa-square fa-stack-2x"></i>
                    <i class="fa fa-caret-down fa-inverse fa-stack-1x"></i>
                </span>
            </div>
        </div>
        <?php if(!is_null($date->capacity)): ?>
        <div class="row">
            <div class="col-md-12">
                A maximum of <?php echo e($date->capacity); ?> participants will be on this tour
            </div>
        </div>
        <?php endif; ?>
    </div>
    <div class="col-md-12 second-row">
        <div class="row">
            <div class="col-md-6">
                Starting time
                <span style="display: block;"><?php echo e(date('h:i A',strtotime($date->starting_time))); ?></span>
            </div>
            <div class="col-md-6 price-all-details">
                <div class="row">
                    <div class="col-md-6">
                        Price Breakdown
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <?php echo e($item->price_definition->st_price_name); ?> <?php echo e($request->st_no); ?> x 
                        <?php echo e(Vars::getVar('€')); ?><?php echo e($date->st_price); ?>

                    </div>
                    <div class="col-md-6 text-right">
                        <?php echo e(Vars::getVar('€')); ?><?php echo e($request->st_no*$date->st_price); ?>

                    </div>
                </div>
                <?php if($request->sec_no!=0): ?>
                <div class="row">
                    <div class="col-md-6">
                        <?php echo e($item->price_definition->sec_price_name); ?> <?php echo e($request->sec_no); ?> x 
                        <?php echo e(Vars::getVar('€')); ?><?php echo e($date->sec_price); ?>

                    </div>
                    <div class="col-md-6 text-right">
                        <?php echo e(Vars::getVar('€')); ?><?php echo e($request->sec_no*$date->sec_price); ?>

                    </div>
                </div>
                <?php endif; ?>
                <?php if($request->third_no!=0): ?>
                <div class="row">
                    <div class="col-md-6">
                        <?php echo e($item->price_definition->third_price_name); ?> <?php echo e($request->third_no); ?> x 
                        <?php echo e(Vars::getVar('€')); ?><?php echo e($date->third_price); ?>

                    </div>
                    <div class="col-md-6 text-right">
                        <?php echo e(Vars::getVar('€')); ?><?php echo e($request->third_no*$date->third_price); ?>

                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <div class="row price-add-cart">
            <div class="col-md-12 text-right">
                <form method="post" action="<?php echo e(route('reservation.cart.add')); ?>">
                    <?php echo e(csrf_field()); ?> 
                    <input type="hidden" name="item_id" value="<?php echo e($date->item->id); ?>" />
                    <input type="hidden" name="price_id" value="<?php echo e($date->id); ?>" />
                    <input type="hidden" name="price" value="<?php echo e(\App\Http\Controllers\Web\ItemsController::getTotalPriceAmount($request,$date)); ?>">
                    <input type="hidden" name="date" value="<?php echo e($tourDate); ?>">
                    <input type="hidden" name="st_no" value="<?php echo e($request->st_no); ?>">
                    <input type="hidden" name="sec_no" value="<?php echo e($request->sec_no); ?>">
                    <input type="hidden" name="third_no" value="<?php echo e($request->third_no); ?>">
                    <input type="hidden" name="discount" value="<?php echo e($date->discount); ?>">
                  <button class="btn btn-info">Add to Cart</button>  
                </form>
                
            </div>
        </div>
    </div>

</div>
<?php $oder++; ?>
<?php else: ?>
<div class="row price-plane-avaiable price-not-active">
    <div class="col-md-12 first-row">
        <div class="row" id="not-available">
            <div class="col-md-6">
                <?php echo (!is_null($date->language))?ucfirst($date->language)." Tour":null; ?>

                <?php echo (!is_null($date->capacity))?": Up to".$date->capacity." People":null; ?>

                <span class="not-available-warning">Not available</span>
                <div class="next-date">
                    Next available date: <a href="#" id="another-date" data-date="<?php echo e(date('M d,Y',strtotime('next '.$date->week_day))); ?>">
                        <?php echo e(date('l, F d Y',strtotime('next '.$date->week_day))); ?>

                    </a>
                </div>
            </div>
        </div>
    </div>


</div>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>


