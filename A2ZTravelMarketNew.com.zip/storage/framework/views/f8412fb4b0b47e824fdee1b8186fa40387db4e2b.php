<?php $__env->startSection('title','Items Panel'); ?>
<?php $__env->startSection('Extra_Css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('adminlte/plugins/datatables/dataTables.bootstrap.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/admin/style.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <!-- Directory&Header -->
    <section class="content-header">
        <h1> Reservations <small>Reservations tables</small> </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> C-Panel</a></li>
            <li><a href="#">Reservations</a></li>
        </ol>
    </section>
    <!-- end Directory&Header -->
    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-xs-12">
                <!-- box -->

                <!-- end box 1 -->
                <!-- /.box -->
                <div class="box">
                    <div class="box-header">
                        <h3 class="box-title">Reservations Data With Full Features</h3>
                    </div>
                    <!-- /.box-header -->
                    <div class="box-body">
                        <table id="example1" class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Date</th>
                                    <th>Tours</th>
                                    <th>Transfers</th>
                                    <th>Total</th>
                                    <th>Deposit</th>
                                    <th>Paid</th>
                                    <th>#Action</th>
                                </tr>
                            </thead>
                            <tbody>

                                <?php $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <tr>
                                    <td><?php echo e($reservation->name); ?></td>
                                    <td><?php echo e($reservation->email); ?></td>
                                    <td><?php echo e($reservation->date); ?></td>
                                    <td><?php echo e($reservation->tours); ?></td>
                                    <td><?php echo e($reservation->transfers); ?></td>
                                    <td><?php echo e($reservation->total); ?></td>
                                    <td><?php echo e($reservation->deposit); ?></td>
                                    <td> <?php echo ($reservation->paid)? '<i class="fa fa-circle text-green"></i>':'<i class="fa fa-circle text-gray"></i>'; ?> </td>
                                    <td><div class="btn-group">
                                            <button type="button" class="btn btn-default">Action</button>
                                            <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown"> <span class="caret"></span> <span class="sr-only">Toggle Dropdown</                                                            span> </button>
                                            <ul class="dropdown-menu" role="menu">
                                                <li><a href="<?php echo e(route('Reservation.show',['id'=>$reservation->id])); ?>">Show</a></li>
                                            </ul>
                                        </div></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            </tbody>

                            <tfoot>
                                <tr>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Date</th>
                                    <th>Tours</th>
                                    <th>Transfers</th>
                                    <th>Total</th>
                                    <th>Deposit</th>
                                    <th>Paid</th>
                                    <th>#Action</th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('Extra_Js'); ?>
<script src="<?php echo e(asset('js/admin/admin.js')); ?>"></script>
<script src="<?php echo e(asset('adminlte/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('adminlte/plugins/datatables/dataTables.bootstrap.min.js')); ?>"></script>
<script>
$(function() {
    $("#example1").DataTable();
    $('#example2').DataTable({
        "paging": true,
        "lengthChange": false,
        "searching": false,
        "ordering": true,
        "info": true,
        "autoWidth": false
    });
});
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('Admin.Layouts.Layout_Basic', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>