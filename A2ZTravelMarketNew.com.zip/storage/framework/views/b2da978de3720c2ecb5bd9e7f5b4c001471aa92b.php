you have one new Notification <br>
to see your new Notification , Please Click <a href="<?php echo e(route('Reservation.show',['id'=>$id])); ?>">Here</a>

