<?php $__env->startSection('meta_tags'); ?>
<title><?php echo e($item->title); ?></title>
<meta name="keywords" content="<?php echo e($item->keywords); ?>" />
<meta name="description" content="<?php echo e($item->description); ?>" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row exc-container">
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <div class="row">
                    <ul class="list-inline directory">
                        <li><a href=""><?php echo e(Vars::getVar("Home")); ?><span class="glyphicon glyphicon-chevron-right" style="font-size: 10px;"></span></a></li>
                        <li><a href=""><?php echo e($item->sort->name); ?> Tours<span class="glyphicon glyphicon-chevron-right"></span></a>
                        <li><a href=""><?php echo e($item->name); ?></a>
                    </ul>
                    <h1><?php echo e($item->title); ?></h1>
                </div>
                <div class="row">

                    <div class="col-md-5 item-img">

                        <div class="item-img-shadow"></div>
                        <img src="<?php echo e(asset('images/items/'.$item->img)); ?>" style="width: 100%" alt="">
                    </div>
                    <div class="col-md-7" style="font-size: 17px; position: relative;">
                        <span class="glyphicon glyphicon-triangle-left item-img-label"></span>
                        <div class="row item-tripadvisor-icon">
                            <div class="row">
                                <div class="col-md-3 col-lg-2" style="margin-top: -5px;">
                                    <div class="fb-like" data-href="http://www.sharmtour.com" data-layout="button_count" data-action="like" data-size="small" data-show-faces="false" data-share="false"></div>
                                </div>
                                <div class="col-md-3 col-lg-2">
                                    <a href="https://twitter.com/share" class="twitter-share-button" data-url="http://sharmwondes.com" data-count="none">Tweet</a>
                                </div>
                                <div class="col-md-4 col-lg-3">
                                    <script src="https://apis.google.com/js/platform.js" async defer></script>
                                    <div class="g-follow" data-annotation="bubble" data-height="20" data-href="//plus.google.com/u/0/113067422417563827751" data-rel="publisher"></div>
                                </div>
                                <div class="col-md-2"><a href="//www.pinterest.com/pin/create/button/" data-pin-do="buttonBookmark"  data-pin-color="red"><img src="//assets.pinterest.com/images/pidgets/pinit_fg_en_rect_red_20.png" /></a>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <?php echo e($item->intro); ?>

                        </div>
                    </div>
                </div>
                <div class="row item-details-container">



                    <ul class="nav nav-tabs item-details-tab">
                        <li class="active"><a data-toggle="tab" href="#home"><span class="glyphicon glyphicon-stats" ></span> <?php echo e(Vars::getVar("Itinerary")); ?></a></li>
                        <li><a data-toggle="tab" href="#menu1"><span class="glyphicon glyphicon-picture"></span> <?php echo e(Vars::getVar("Gallery")); ?></a></li>

                    </ul>

                    <div class="tab-content item-tab-style" >
                        <div id="home" class="tab-pane fade in active">
                            <h3><?php echo e(Vars::getVar("Highlights")); ?></h3>
                            <?php if(isset($item->exploration->txt)): ?>
                            <?php echo $item->exploration->txt; ?>

                            <?php endif; ?>
                            <div class="row small-gallery">
                                <div class="small-gallery-label">

                                    <span class="small-gallery-label-span"><span class="glyphicon glyphicon-picture"></span> <?php echo e(Vars::getVar("Small_Gallery")); ?></span></div>
                                <?php if(isset($item->itemsgallrie)): ?>
                                <?php $__currentLoopData = $item->itemsgallrie->slice(0,4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <div class="col-md-3 img-item-small-gallery">
                                    <div>
                                        <img  src="<?php echo e(asset('images/gallery/thumb/'.$img->img)); ?>" alt="<?php echo e($item->title); ?>">
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                <?php endif; ?>


                            </div>

                            <?php if(count($item->inclusion)>0): ?>
                            <div class="row">
                                <h3 class="item-details-label-header">
                                    <span class="glyphicon glyphicon-ok"></span> <?php echo e(Vars::getVar("Our_Service_includes")); ?></h3>
                                <ul style="margin:0px 0px 0px 30px; font-weight: bold;">
                                    <?php $__currentLoopData = $item->inclusion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inclusion): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <li><?php echo e($inclusion->txt); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                </ul>
                            </div>
                            <?php endif; ?>


                            <?php if(count($item->exclusion)>0): ?>
                            <div class="row">
                                <h3 class="item-details-label-header">
                                    <span class="glyphicon glyphicon-remove"></span> <?php echo e(Vars::getVar("Our_Service_Not_includes")); ?></h3>
                                <ul style="margin:0px 0px 0px 30px; font-weight: bold;">
                                    <?php $__currentLoopData = $item->exclusion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exclusion): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <li><?php echo e($exclusion->txt); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                </ul>
                            </div>
                            <?php endif; ?>


                            <?php if(count($item->additional)>0): ?>
                            <div class="row">
                                <h3 class="item-details-label-header">
                                    <span class="glyphicon glyphicon-star"></span> <?php echo e(Vars::getVar("Recommendation")); ?></h3>
                                <ul style="margin:0px 0px 0px 30px; font-weight: bold;">
                                    <?php $__currentLoopData = $item->additional; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $additional): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <li><?php echo e($additional->txt); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                </ul>
                            </div>
                            <?php endif; ?>

                        </div>
                        <div id="menu1" class="tab-pane fade">
                            <h3>Menu 1</h3>
                            <p>Some content in menu 1.</p>
                        </div>

                    </div>
                </div>
            </div>
            <div class="col-md-4" style="padding: 0px 0px 0px 20px; margin: 0px;">
                <div class="col-md-12">
                    <?php if(isset($item->price)): ?>
                    <form action="<?php echo e(route('add.to.cart',['id'=>$item->id])); ?>" method="post">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"/>
                        <input type="hidden" name="item_id" value="<?php echo e($item->id); ?>"/>
                        <div class="row booking-form">

                            <div class="row booking-form-price-first">
                                <div class="col-md-5 col-lg-7"><span><?php echo e($item->price->st_name); ?></span></div>
                                <div class="col-md-7 col-lg-5"><?php echo e($item->price->st_price); ?>.00 <span><?php echo e(Vars::getVar("$")); ?></span></div>
                            </div>
                            <div class="row booking-form-price-sec">
                                <div class="col-md-5 col-lg-7"><span><?php echo e($item->price->sec_name); ?></span></div>
                                <div class="col-md-7 col-lg-5"><?php echo e($item->price->sec_price); ?>.00 <span><?php echo e(Vars::getVar("$")); ?></span></div>
                            </div>


                            <div class="row booking-form-date">
                                <h3><?php echo e(Vars::getVar("Select_Travel_Date")); ?></h3>
                                <div class="col-md-3"><?php echo e(Vars::getVar("Date")); ?></div>
                                <div class="col-md-9">
                                    <div class="input-group">
                                        <div class="input-group-addon booking-form-date-icon">
                                            <i class="fa fa-calendar"></i>
                                        </div>
                                        <input name="date" type="text" class="form-control" data-inputmask="'alias': 'dd/mm/yyyy'" data-mask>
                                    </div>
                                </div>
                            </div>
                            <h3><?php echo e(Vars::getVar("Enter_Total_Number_of_Travelers")); ?></h3>
                            <div class="row">
                                <div class="col-md-3"><?php echo e($item->price->st_name); ?></div>
                                <div class="col-md-3"><input name="st_no" type="number" class="form-control"></div>
                                <div class="col-md-3"><?php echo e($item->price->sec_name); ?></div>
                                <div class="col-md-3"><input name="sec_no" type="number" class="form-control"></div>
                            </div>
                            <div class="row text-center" style="padding-top: 20px;">
                                <button class="btn btn-danger btn-lg">
                                    <span class="glyphicon glyphicon-shopping-cart"></span> add to Basket <span class="glyphicon glyphicon-arrow-right"></span>
                                </button>
                                <h3 class="text-center price-gurantee"><a href=""><span class="glyphicon glyphicon-bookmark"></span> Low Price Guarantee</a></h3>
                            </div>
                        </div>
                    </form>
                    <?php endif; ?>
                </div>

                <div class="row">
                    <div class="col-md-12">
                        <img src="<?php echo e(asset('images/banner.jpg')); ?>" alt="" style="width:100%;">
                    </div>
                </div>
                <div class="row">
                    <h1><?php echo e($item->sort->title); ?></h1>
                    <ul>
                        <?php $__currentLoopData = $item->sort->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leftItem): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <li><a href="<?php echo e(route('tour.show',['city'=>urlencode($leftItem->sort->name),'tour'=>urlencode($leftItem->name),'id'=>$leftItem->id])); ?>"><?php echo e($leftItem->title); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-1"></div>
        <div class="col-md-10">
            <div class="row more-attractions">
                <h3><?php echo e(Vars::getVar("More_Things_to_Do_in_Sharm_el_Sheikh")); ?></h3>
                <ul class="list-inline">
                    <?php $__currentLoopData = $Categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Seccategory): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <li><span><a href="<?php echo e(route('cities.show',['city'=>urlencode($Seccategory->name),'id'=>$Seccategory->id])); ?>"><?php echo e($Seccategory->title); ?></a></span></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </ul>
            </div>
            <div class="row more-attractions">
                <h3><?php echo e(Vars::getVar("Top_Sharm_el_Sheikh_Attractions")); ?></h3>
                <ul class="list-inline">
                    <?php $__currentLoopData = $Categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $LinkCategory): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <?php $__currentLoopData = $LinkCategory->items->where('recommended',"=",1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $LinkItems): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>

                    <li><span><a href="<?php echo e(route('tour.show',['city'=>urlencode($LinkCategory->name),'tour'=>urlencode($LinkItems->name),'id'=>$LinkItems->id])); ?>"><?php echo e($LinkItems->title); ?></a></span></li>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </ul>
            </div>
        </div>


    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('extra-plugged-in'); ?>
<script>(function(d, s, id) {
    var js, fjs = d.getElementsByTagName(s)[0];
    if (d.getElementById(id))
        return;
    js = d.createElement(s);
    js.id = id;
    js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.9&appId=184060755364562";
    fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('_extra_js'); ?>
<script src="<?php echo e(asset('adminlte/plugins/select2/select2.full.min.js')); ?>"></script>
<!-- Input Mask -->
<script src="<?php echo e(asset('adminlte/plugins/input-mask/jquery.inputmask.js')); ?>"></script>
<script src="<?php echo e(asset('adminlte/plugins/input-mask/jquery.inputmask.date.extensions.js')); ?>"></script>
<script src="<?php echo e(asset('adminlte/plugins/input-mask/jquery.inputmask.extensions.js')); ?>"></script>
<script>
$(function() {
//Initialize Select2 Elements
    $(".select2").select2();

//Datemask dd/mm/yyyy
    $("#datemask").inputmask("dd/mm/yyyy", {"placeholder": "dd/mm/yyyy"});
//Datemask2 mm/dd/yyyy
    $("#datemask2").inputmask("mm/dd/yyyy", {"placeholder": "mm/dd/yyyy"});
//Money Euro
    $("[data-mask]").inputmask();

});
</script>
<script>!function(d, s, id) {
        var js, fjs = d.getElementsByTagName(s)[0], p = /^http:/.test(d.location) ? 'http' : 'https';
        if (!d.getElementById(id)) {
            js = d.createElement(s);
            js.id = id;
            js.src = p + '://platform.twitter.com/widgets.js';
            fjs.parentNode.insertBefore(js, fjs);
        }
    }(document, 'script', 'twitter-wjs');</script>

<!-- Place this tag where you want the +1 button to render. -->

<!-- Place this tag after the last +1 button tag. -->




<!-- Please call pinit.js only once per page -->
<script type="text/javascript" async defer src="//assets.pinterest.com/js/pinit.js"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('_extra_css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('adminlte/plugins/datepicker/datepicker3.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('adminlte/plugins/select2/select2.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Web.Layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>