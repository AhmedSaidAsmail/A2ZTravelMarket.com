<?php $__env->startSection('title','Items Panel'); ?>
<?php $__env->startSection('Extra_Css'); ?>

<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/admin/style.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <!-- Directory&Header -->
    <section class="content-header">
        <h1> Topics <small>Topics tables</small> </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> C-Panel</a></li>
            <li><a href="#">Items</a></li>
        </ol>
    </section>
    <!-- end Directory&Header -->
    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-xs-12">
                <!-- box -->
                <div class="box">
                    <div class="box-header with-border">
                        <div class="form-group">
                            <button type="submit" class="form-control btn btn-default" id="addNew"><i class="fa fa-database"></i> Update <?php echo e($topic->name); ?></button>
                        </div>

                        <?php if(count($errors)>0): ?>
                        <div class="alert alert-danger alert-dismissible">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <h4><i class="icon fa fa-ban"></i> Alert!</h4>
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            </ul>
                        </div>

                        <?php endif; ?>
                    </div>
                    <div id="basicToggle">
                        <form method="post" action="<?php echo e(route('Topics.update',['id'=>$topic->id])); ?>" enctype="multipart/form-data">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <input type="hidden" name="_method" value="PUT">
                            <div class="box-body">
                                <div class="row">
                                    <div class="col-md-5">
                                        <div class="form-group">
                                            <label>Item Name:</label>
                                            <input class="form-control" name="name" value="<?php echo e($topic->name); ?>" placeholder="Main category Name" required>
                                        </div>
                                    </div>
                                    <div class="col-md-5">
                                        <div class="form-group">
                                            <label>Item Title:</label>
                                            <input class="form-control" name="title" value="<?php echo e($topic->title); ?>" placeholder="Main category Title" required>
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label>Arrangement:</label>
                                            <input type="number" value="<?php echo e($topic->arrangement); ?>" class="form-control" name="arrangement">
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Top</label>
                                            <select class="form-control" name="top">

                                                <option value="1">True</option>
                                                <option value="0" <?php echo (!$topic->top)?'selected="selected"':''; ?>>False</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Footer</label>
                                            <select class="form-control" name="footer">

                                                <option value="1">True</option>
                                                <option value="0" <?php echo (!$topic->footer)?'selected="selected"':''; ?>>False</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Side Bar</label>
                                            <select class="form-control" name="sidebar">

                                                <option value="1">True</option>
                                                <option value="0" <?php echo (!$topic->sidebar)?'selected="selected"':''; ?>>False</option>
                                            </select>
                                        </div>
                                    </div>


                                </div>
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Top Link Name:</label>
                                            <input class="form-control" value="<?php echo e($topic->top_link); ?>" name="top_link" >
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Footer Link Name:</label>
                                            <input class="form-control" value="<?php echo e($topic->footer_link); ?>" name="footer_link" >
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>side Bar Link Name:</label>
                                            <input class="form-control" value="<?php echo e($topic->sidebar_link); ?>" name="sidebar_link">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Keywords:</label>
                                            <input class="form-control" name="keywords" value="<?php echo e($topic->keywords); ?>" placeholder="-- Keywords --" >
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Description:</label>
                                            <input class="form-control" name="description" value="<?php echo e($topic->description); ?>" placeholder="-- Description --" >
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group"> <input type="submit" class="btn btn-primary" value="Update Topic"></div>
                                <div class="form-group"> </div>
                            </div>
                        </form>
                    </div>
                </div>
                <!-- end box 1 -->

            </div>
        </div>


        <?php if(Session::has('updateArticles')): ?>
        <div class="alert alert-success alert-dismissible">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <h4><i class="icon fa fa-ban"></i> Alert!</h4>
            <?php echo e(Session('updateArticles')); ?>

        </div>
        <?php endif; ?>
        <?php $Topics_text = $topic->Topics_text; ?>
        <?php if(!is_null($Topics_text)): ?>
        <form action="<?php echo e(route('Articles.update',['id'=>$Topics_text->id])); ?>" method="post">
            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
            <input type="hidden" name="_method" value="PUT">

            <div class="row">
                <div class="col-md-12">
                    <div class="box box-info">
                        <div class="box-header">
                            <h3 class="box-title">Topic Articles
                                <small>Update Articles</small>
                            </h3>
                            <!-- tools box -->
                            <div class="pull-right box-tools">
                                <button type="button" class="btn btn-info btn-sm" data-widget="collapse" data-toggle="tooltip" title="Collapse">
                                    <i class="fa fa-minus"></i></button>
                                <button type="button" class="btn btn-info btn-sm" data-widget="remove" data-toggle="tooltip" title="Remove">
                                    <i class="fa fa-times"></i></button>
                            </div>
                            <!-- /. tools -->
                        </div>
                        <!-- /.box-header -->
                        <div class="box-body pad">
                            <div class="form-group">
                                <textarea id="editor1" name="txt" rows="10" cols="80">
                                            <?php echo e($topic->Topics_text->txt); ?>

                                </textarea>
                            </div>

                            <div class="form-group">
                                <button class="btn btn-primary btn-block">Update</button>
                            </div>

                            <div class="form-group">
                                <a href="<?php echo e(route('Gallery.index',[$topic->id])); ?>" class="btn btn-default btn-block">Images</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
        <?php endif; ?>







    </section>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('Extra_Js'); ?>
<script src="<?php echo e(asset('js/admin/admin.js')); ?>"></script>
<script src="https://cdn.ckeditor.com/4.5.7/standard/ckeditor.js"></script>

<script>
$(function() {
    // Replace the <textarea id="editor1"> with a CKEditor
    // instance, using default configuration.
    CKEDITOR.replace('editor1');
    //bootstrap WYSIHTML5 - text editor
    $(".textarea").wysihtml5();
});
</script>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('Admin.Layouts.Layout_Basic', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>