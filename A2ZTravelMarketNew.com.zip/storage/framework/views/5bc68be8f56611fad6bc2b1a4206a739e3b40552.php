
<!-- header menu -->
<div class="row top-header">
    <div class="container text-right">
        <ul class="list-inline">
            <li><a href="<?php echo e(route('home')); ?>"><i class="fa fa-home fa-lg top-home" aria-hidden="true"></i></a></li>
            <?php $__currentLoopData = App\MyModels\Admin\Topic::where('top',1)->orderBy('arrangement','asc')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $top): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <li><a href="<?php echo e(route('topics.show',['topicsName'=>urlencode($top->name)])); ?>">
                    <?php echo e($top->top_link); ?> </a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        </ul>
    </div>
</div>
<!-- end header menu -->
<!-- navigator Menu -->
<div class="row main-nav-container main-nav-normal animated" id="main-nav">
    <div class="container" style="position: relative;">
        <ul class="list-inline main-nav">
            <li class="nav-logo">
                <div class="main-nav-logo"></div>
            </li>
            <?php $__currentLoopData = App\MyModels\Admin\Sort::where('status',1)->limit(7)->orderBy('arrangement')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <?php if(isset($activeLink) && $activeLink==$category->id): ?>
            <?php $class = ' active-link' ?>
            <?php else: ?>
            <?php $class = null ?>
            <?php endif; ?>
            <li class="nav-item<?php echo e($class); ?>">
                <a href="<?php echo e(route('cities.show',['city'=>urlencode($category->name),'id'=>$category->id])); ?>"><?php echo e($category->name); ?></a>
                <?php if(count($category->items)>0): ?>
                <div class="sub-nav">
                    <div class="sub-nav-container">
                        <div class="row">
                            <div class="col-md-6" style="position: relative; padding-right: 0px;">
                                <ul>
                                    <?php $__currentLoopData = $category->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemmenu): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>

                                    <li>
                                        <a href="<?php echo e(route('tour.show',['city'=>urlencode($category->name),'tour'=>urlencode($itemmenu->name),'id'=>$itemmenu->id])); ?>">
                                            <?php echo e($itemmenu->title); ?></a>
                                        <div class="sub-nav-item-details">
                                            <div class="sub-nav-info">
                                                <div class="sub-nav-info-img">
                                                    <img class="img-abs-center" src="<?php echo e(asset('images/items/thumb/'.$itemmenu->img)); ?>" alt="">
                                                </div>
                                                <h1><?php echo e($itemmenu->title); ?></h1>
                                                <p>
                                                    <?php
                                                    echo substr($itemmenu->intro, 0, 90);
                                                    ?>
                                                    ....
                                                </p>

                                            </div>

                                        </div>
                                    </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                </ul>
                            </div>
                        </div>

                    </div>

                </div>
                <?php endif; ?>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            <li class="nav-item-right"><a href="<?php echo e(route('cart')); ?>"><?php echo e(Session::has('cart')?Session::get('cart')->totalQty:0); ?>

                    <?php echo e(Vars::getVar('My_Trips')); ?>

                    <span class="fa-stack">
                        <i class="fa fa-circle fa-stack-2x"></i>
                        <i class="fa fa-shopping-cart fa-stack-1x fa-inverse"></i>
                    </span>
                </a></li>
        </ul>

    </div>
</div>
<!-- end navigator menu -->