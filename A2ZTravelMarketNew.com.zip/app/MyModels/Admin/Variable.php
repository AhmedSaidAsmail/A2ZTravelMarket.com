<?php
namespace App\MyModels\Admin;

use Illuminate\Database\Eloquent\Model;

class Variable extends Model {

    protected $fillable = ["word", "lang"];

}