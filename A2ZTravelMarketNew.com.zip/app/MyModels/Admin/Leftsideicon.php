<?php
namespace App\MyModels\Admin;

use Illuminate\Database\Eloquent\Model;

class Leftsideicon extends Model {

    protected $fillable = ['name', 'link', 'img'];

}